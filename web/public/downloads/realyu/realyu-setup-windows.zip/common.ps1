﻿$ErrorActionPreference = 'Stop'
$env:PSModulePath = Join-Path $PSHOME 'Modules'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = [Text.UTF8Encoding]::new($false)
$utf8 = [Text.UTF8Encoding]::new($false)
[AppContext]::SetSwitch('Switch.System.IO.UseLegacyPathHandling',$false)
[AppContext]::SetSwitch('Switch.System.IO.BlockLongPaths',$false)
Add-Type -AssemblyName System.Web.Extensions
Add-Type -Path (Join-Path $PSScriptRoot 'native.cs') -ReferencedAssemblies 'System.Web.Extensions.dll'
$json = [System.Web.Script.Serialization.JavaScriptSerializer]::new()
$json.MaxJsonLength = 67108864
$json.RecursionLimit = 200
function Parse-Json([string]$Value) { return ,$json.DeserializeObject($Value) }
function To-Json($Value) { ConvertTo-Json -InputObject $Value -Depth 80 -Compress }
function Assert-LocalPath([string]$Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        # Use the same extended paths as long-path file operations when checking links.
        $native=if ($current.StartsWith('\\?\')) { $current } elseif ($current.StartsWith('\\')) { '\\?\UNC\'+$current.Substring(2) } else { '\\?\'+$current }
        if ([IO.File]::Exists($native) -or [IO.Directory]::Exists($native)) {
            if ([IO.File]::GetAttributes($native) -band [IO.FileAttributes]::ReparsePoint) { throw 'PATH_UNSAFE' }
        }
        $parent = [IO.Path]::GetDirectoryName($current)
        if ($parent -eq $current) { break }
        $current = $parent
    }
}
function New-PrivateDirectory([string]$Path) {
    Assert-LocalPath $Path
    $null = [IO.Directory]::CreateDirectory($Path)
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
    foreach ($identity in @($sid, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'))) {
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($identity, 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow'))
    }
    [IO.Directory]::SetAccessControl($Path, $acl)
}
function Write-Atomic([string]$Path, [byte[]]$Data) {
    Assert-LocalPath $Path
    [RealyuNative.Files]::Atomic($Path, $Data)
}
function Get-Sha([string]$Path) {
    Assert-LocalPath $Path
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}
function Error-Code($Failure, [string]$Fallback = 'SETUP_FAILED') {
    $errorObject = $Failure.Exception
    while ($errorObject) {
        if ($errorObject.Message -cmatch '^[A-Z][A-Z0-9_]{3,70}$') { return $errorObject.Message }
        if ($errorObject -is [UnauthorizedAccessException]) { return 'FILESYSTEM_ACCESS_DENIED' }
        if ($errorObject -is [IO.FileNotFoundException] -or $errorObject -is [IO.DirectoryNotFoundException]) { return 'FILE_NOT_FOUND' }
        if ($errorObject -is [IO.IOException]) { return 'FILESYSTEM_ERROR' }
        $errorObject = $errorObject.InnerException
    }
    return $Fallback
}
function Explain-Error([string]$Code) {
    $messages=Parse-Json ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'errors.json'),$utf8))
    if ($messages.ContainsKey($Code)) { return ,$messages[$Code] }
    if ($Code -match '^IMAGE_HTTP_(\d+)$') { return ,@(('图片服务返回 HTTP '+$Matches[1]+'。'), '检查服务状态和网络后再决定是否重试；本次未自动重试。') }
    return ,$messages['SETUP_FAILED']
}
function Call-Rpc($Client, [string]$Method, $Params) {
    return ,(Parse-Json ($Client.Call($Method, (To-Json $Params), 60000)))
}
function Open-Rpc([string]$Exe, [string]$Directory) {
    $client = [RealyuNative.Rpc]::new($Exe, $Directory, [string[]]@('-c','features.shell_snapshot=false','app-server'))
    try {
        $null = Call-Rpc $client 'initialize' @{clientInfo=@{name='realyu_setup';version='1.4.32'};capabilities=@{experimentalApi=$true}}
        $client.Send('{"method":"initialized","params":{}}')
        return $client
    } catch { $client.Dispose(); throw }
}
function Assert-SessionsIdle([string]$Directory) {
    $locks = Join-Path $Directory 'thread-writer-locks'
    Assert-LocalPath $locks
    [RealyuNative.Files]::Idle($locks)
}

function Get-CodexCandidates {
    if ($env:REALYU_CODEX_EXE) {
        $explicit=[Environment]::ExpandEnvironmentVariables($env:REALYU_CODEX_EXE.Trim().Trim('"'))
        if ($explicit -notmatch '^[A-Za-z]:[\\/]' -or -not [IO.File]::Exists($explicit)) { throw 'CODEX_OVERRIDE_INVALID' }
        return $explicit
    }
    $candidates=[Collections.Generic.List[string]]::new()
    $roots=[Collections.Generic.List[string]]::new()
    foreach ($packageName in @('*Codex*','*ChatGPT*')) {
        try { Get-AppxPackage $packageName -ErrorAction Stop | ForEach-Object { if ($_.InstallLocation) { $roots.Add($_.InstallLocation) } } } catch { }
    }
    foreach ($directory in @($env:LOCALAPPDATA,$env:ProgramFiles,${env:ProgramFiles(x86)},$env:ProgramW6432)) {
        if (-not $directory) { continue }
        foreach ($relative in @('OpenAI\Codex','Codex','ChatGPT','OpenAI\ChatGPT')) { $roots.Add((Join-Path $directory $relative)) }
        if ($directory -eq $env:LOCALAPPDATA) {
            foreach ($relative in @('Programs\Codex','Programs\OpenAI\Codex','Programs\ChatGPT','Programs\OpenAI\ChatGPT')) { $roots.Add((Join-Path $directory $relative)) }
        }
    }
    $views=@([Microsoft.Win32.RegistryView]::Default)
    if ([Environment]::Is64BitOperatingSystem) { $views=@([Microsoft.Win32.RegistryView]::Registry64,[Microsoft.Win32.RegistryView]::Registry32) }
    foreach ($hive in @([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryHive]::LocalMachine)) {
        foreach ($view in $views) {
            $base=$null;$uninstall=$null
            try {
                $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey($hive,$view)
                $executables=[Collections.Generic.List[string]]::new()
                foreach ($name in @('Codex.exe','ChatGPT.exe')) {
                    $entry=$null
                    try { $entry=$base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\App Paths\'+$name);if ($entry -and $entry.GetValue('') -is [string]) { $executables.Add($entry.GetValue('')) } } finally { if ($entry) {$entry.Dispose()} }
                }
                $uninstall=$base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Uninstall')
                if ($uninstall) {
                    foreach ($name in $uninstall.GetSubKeyNames()) {
                        $entry=$null
                        try {
                            $entry=$uninstall.OpenSubKey($name)
                            if (-not $entry -or [string]$entry.GetValue('DisplayName') -notmatch '^(?:OpenAI\s+)?(?:Codex|ChatGPT)(?:\s|$)') { continue }
                            $location=$entry.GetValue('InstallLocation')
                            if ($location -is [string] -and $location.Trim()) { $roots.Add([Environment]::ExpandEnvironmentVariables($location.Trim().Trim('"'))) }
                            $icon=$entry.GetValue('DisplayIcon')
                            if ($icon -is [string] -and $icon.Trim()) { $executables.Add(($icon.Trim() -replace ',\s*-?\d+\s*$','')) }
                        } catch { continue } finally { if ($entry) {$entry.Dispose()} }
                    }
                }
                foreach ($value in $executables) {
                    $path=[Environment]::ExpandEnvironmentVariables($value.Trim().Trim('"'))
                    if ($path -notmatch '^[A-Za-z]:[\\/].*\.exe$') { continue }
                    $roots.Add([IO.Path]::GetDirectoryName($path))
                    # Registry GUI entrypoints are never launched as a CLI.
                    if ($path -match '[\\/](?:resources|bin)[\\/]codex\.exe$') { $candidates.Add($path) }
                }
            } catch { } finally { if ($uninstall) {$uninstall.Dispose()};if ($base) {$base.Dispose()} }
        }
    }
    foreach ($root in ($roots | Select-Object -Unique)) {
        if ($root -notmatch '^[A-Za-z]:[\\/]') { continue }
        foreach ($part in @('app\resources\codex.exe','resources\codex.exe','bin\codex.exe','resources\codex-cli\bin\codex.exe','app\resources\codex-cli\bin\codex.exe')) { $candidates.Add((Join-Path $root $part)) }
        Get-ChildItem -LiteralPath (Join-Path $root 'bin') -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc -Descending | ForEach-Object { $candidates.Add((Join-Path $_.FullName 'codex.exe')) }
    }
    $prefixes=[Collections.Generic.List[string]]::new()
    if ($env:APPDATA) { $prefixes.Add((Join-Path $env:APPDATA 'npm')) }
    if ($env:npm_config_prefix) { $prefixes.Add($env:npm_config_prefix) }
    $pathExecutables=[Collections.Generic.List[string]]::new()
    foreach ($command in @(Get-Command codex.exe,codex.cmd,codex.ps1 -All -ErrorAction SilentlyContinue)) {
        if (-not $command.Source -or $command.Source -notmatch '^[A-Za-z]:[\\/]') { continue }
        if ([IO.Path]::GetExtension($command.Source) -ieq '.exe') { $pathExecutables.Add($command.Source) }
        else { $prefixes.Add([IO.Path]::GetDirectoryName($command.Source)) }
    }
    foreach ($prefix in ($prefixes | Select-Object -Unique)) {
        if ($prefix -notmatch '^[A-Za-z]:[\\/]') { continue }
        $scope=Join-Path $prefix 'node_modules\@openai'
        $packages=@(Get-ChildItem -LiteralPath $scope -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'codex' -or $_.Name -like 'codex-*' })
        $packages+=@(Get-ChildItem -LiteralPath (Join-Path $scope 'codex\node_modules\@openai') -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'codex-*' })
        foreach ($package in $packages) {
            Get-ChildItem -LiteralPath (Join-Path $package.FullName 'vendor') -Directory -ErrorAction SilentlyContinue | ForEach-Object { $candidates.Add((Join-Path $_.FullName 'codex\codex.exe')) }
        }
    }
    foreach ($path in $pathExecutables) { $candidates.Add($path) }
    return @($candidates | Select-Object -Unique | Where-Object { [IO.File]::Exists($_) })
}

function Find-Codex([string]$ProbeHome) {
    $found=$false;$timedOut=$false;$unsupported=$false
    foreach ($candidate in @(Get-CodexCandidates)) {
        $found=$true;$exe=$candidate
        try {
            try { $probe=[RealyuNative.ProcessHost]::Run($exe,[string[]]@('--version'),$ProbeHome,$null,15000) }
            catch {
                if ($candidate -notlike '*\WindowsApps\*' -or (Error-Code $_) -eq 'CODEX_TIMEOUT') { throw }
                $hash=Get-Sha $candidate;$folder=Join-Path $env:LOCALAPPDATA "Realyu\codex-cli\$hash";New-PrivateDirectory $folder
                $exe=Join-Path $folder 'codex.exe'
                if (-not [IO.File]::Exists($exe)) { [IO.File]::Copy($candidate,$exe) }
                if ((Get-Sha $exe) -ne $hash) { continue }
                $probe=[RealyuNative.ProcessHost]::Run($exe,[string[]]@('--version'),$ProbeHome,$null,15000)
            }
            if ($probe.Code -ne 0 -or $probe.Output -notmatch 'codex-cli\s+([0-9][0-9A-Za-z.+-]*)') { continue }
            $cliVersion=$Matches[1]
            $login=[RealyuNative.ProcessHost]::Run($exe,[string[]]@('login','--help'),$ProbeHome,$null,15000)
            if ($login.Code -ne 0) { continue }
            if (-not $login.Output.Contains('--with-api-key')) { $unsupported=$true;continue }
            $script:codexVersion=$cliVersion
            return $exe
        } catch { if ((Error-Code $_) -eq 'CODEX_TIMEOUT') {$timedOut=$true} }
    }
    if ($timedOut) { throw 'CODEX_PROBE_TIMEOUT' }
    if ($unsupported) { throw 'CODEX_LOGIN_UNSUPPORTED' }
    if ($found) { throw 'CODEX_UNRUNNABLE' }
    throw 'CODEX_NOT_FOUND'
}
