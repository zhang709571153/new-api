﻿# RealYu API WorkBuddy setup 1.2.0. Windows PowerShell 5.1+.
# Accept the copied command key or prompt privately. Never put credentials in URLs or output.
param([string]$ApiKey)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-RealyuWorkBuddyInstall([switch]$Quiet) {
    $candidates = [Collections.Generic.List[string]]::new()
    if ($env:REALYU_WORKBUDDY_EXE) {
        # An explicit executable is authoritative; do not silently use another installation.
        $candidates.Add($env:REALYU_WORKBUDDY_EXE)
    } else {
        if ($env:LOCALAPPDATA) { $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\WorkBuddy\WorkBuddy.exe')) }
        foreach ($directory in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramW6432)) {
            if ($directory) { $candidates.Add((Join-Path $directory 'WorkBuddy\WorkBuddy.exe')) }
        }
        Get-Command WorkBuddy.exe -All -ErrorAction SilentlyContinue | ForEach-Object { if ($_.Source) { $candidates.Add($_.Source) } }
        $views = @([Microsoft.Win32.RegistryView]::Default)
        if ([Environment]::Is64BitOperatingSystem) { $views = @([Microsoft.Win32.RegistryView]::Registry64, [Microsoft.Win32.RegistryView]::Registry32) }
        foreach ($hive in @([Microsoft.Win32.RegistryHive]::CurrentUser, [Microsoft.Win32.RegistryHive]::LocalMachine)) {
            foreach ($view in $views) {
                $base = $null; $app = $null; $uninstall = $null
                try {
                    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey($hive, $view)
                    $app = $base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\App Paths\WorkBuddy.exe')
                    if ($app) {
                        $value = $app.GetValue('')
                        if ($value -is [string] -and $value.Trim()) { $candidates.Add($value) }
                    }
                    $uninstall = $base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Uninstall')
                    if (-not $uninstall) { continue }
                    foreach ($name in $uninstall.GetSubKeyNames()) {
                        $entry = $null
                        try {
                            $entry = $uninstall.OpenSubKey($name)
                            if (-not $entry -or [string]$entry.GetValue('DisplayName') -notmatch '^WorkBuddy(?:\s|$)') { continue }
                            $location = $entry.GetValue('InstallLocation')
                            if ($location -is [string] -and $location.Trim()) {
                                $directory = [Environment]::ExpandEnvironmentVariables($location.Trim().Trim('"'))
                                $candidates.Add((Join-Path $directory 'WorkBuddy.exe'))
                            }
                            $icon = $entry.GetValue('DisplayIcon')
                            if ($icon -is [string] -and $icon.Trim()) {
                                $candidates.Add(($icon.Trim() -replace ',\s*-?\d+\s*$', ''))
                            }
                        } catch { continue } finally { if ($entry) { $entry.Dispose() } }
                    }
                } catch { continue } finally {
                    if ($app) { $app.Dispose() }
                    if ($uninstall) { $uninstall.Dispose() }
                    if ($base) { $base.Dispose() }
                }
            }
        }
    }
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($candidate in $candidates) {
        try {
            $path = [Environment]::ExpandEnvironmentVariables($candidate.Trim().Trim('"'))
            if ($path -notmatch '^[A-Za-z]:[\\/]' -or [IO.Path]::GetFileName($path) -ine 'WorkBuddy.exe') { continue }
            $path = [IO.Path]::GetFullPath($path)
            if (-not $seen.Add($path) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
            $version = 'unknown'
            try { $value = (Get-Item -LiteralPath $path -ErrorAction Stop).VersionInfo.ProductVersion; if ($value -match '^v?\d{1,4}\.\d{1,4}\.\d{1,4}(?:\.\d{1,6})?(?:[-+][0-9A-Za-z.+-]{1,40})?$') { $version = $value } } catch { }
            $known = $version -ne 'unknown'
            $older = $known -and ([version](($version -replace '^v','') -split '[-+]')[0] -lt [version]'5.6.2')
            $script:workbuddyVersion = $version
            if (-not $Quiet -and (-not $known -or $older)) { Write-Host ('[兼容提示] WorkBuddy '+$version+'；版本号仅作参考，继续检查配置格式并备份写入。若客户端无法加载模型或图片工具，请更新 WorkBuddy。') }
            return $path
        } catch { continue }
    }
    throw 'WORKBUDDY_NOT_FOUND'
}

function Invoke-RealyuWorkBuddyApi([string]$Key, [ValidateSet('key', 'models')][string]$Resource) {
    if ($Key -cnotmatch '^sk-[A-Za-z0-9_-]{16,256}$') { throw 'KEY_FORMAT_INVALID' }
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $url = 'https://api.realyu.fun/api/client/key-check'
    if ($Resource -eq 'models') { $url = 'https://api.realyu.fun/v1/models' }
    $request = [Net.HttpWebRequest]::Create($url)
    $request.Method = 'GET'
    $request.AllowAutoRedirect = $false
    # Inherit the Windows user/system proxy.
    $request.ReadWriteTimeout = 30000
    $request.Timeout = 30000
    $request.UserAgent = 'Realyu-WorkBuddy-Setup/1.2.0'
    $request.Headers['Authorization'] = 'Bearer ' + $Key
    try { $response = $request.GetResponse() }
    catch {
        $status = 0
        $failure = $_.Exception
        while ($failure -and $failure -isnot [Net.WebException]) { $failure = $failure.InnerException }
        if ($failure -and $failure.Response -is [Net.HttpWebResponse]) {
            $status = [int]$failure.Response.StatusCode
            $failure.Response.Dispose()
        }
        if ($status -eq 401) { throw 'KEY_REJECTED' }
        if ($status -eq 403) { throw 'KEY_ACCESS_DENIED' }
        if ($status -eq 429) { throw 'KEY_RATE_LIMITED' }
        throw 'KEY_NETWORK_ERROR'
    }
    try {
        if ([int]$response.StatusCode -ne 200) { throw 'KEY_REDIRECT_OR_HTTP_ERROR' }
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        try {
            $buffer=[char[]]::new(1048577);$count=0
            while ($count -lt $buffer.Length) { $read=$reader.Read($buffer,$count,$buffer.Length-$count);if ($read -eq 0) { break };$count+=$read }
            if ($count -gt 1048576) { throw 'KEY_RESPONSE_INVALID' }
            $body=[string]::new($buffer,0,$count)
        } finally { $reader.Dispose() }
        try { $data = $body | ConvertFrom-Json } catch { throw 'KEY_RESPONSE_INVALID' }
        return $data
    } finally { $response.Dispose() }
}

function Test-RealyuWorkBuddyKey([string]$Key) {
    $data = Invoke-RealyuWorkBuddyApi $Key 'key'
    if ($null -eq $data -or -not $data.PSObject.Properties['code'] -or $data.code -ne $true -or
        -not $data.PSObject.Properties['data'] -or $null -eq $data.data -or
        -not $data.data.PSObject.Properties['object'] -or $data.data.object -ne 'token_usage' -or
        -not $data.data.PSObject.Properties['expires_at']) { throw 'KEY_RESPONSE_INVALID' }
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if ($data.data.expires_at -gt 0 -and $data.data.expires_at -lt $now) { throw 'KEY_EXPIRED' }
    # Identity check intentionally allows a valid zero-allowance team Key.
}

function Get-RealyuWorkBuddyModels([string]$Key) {
    $data = Invoke-RealyuWorkBuddyApi $Key 'models'
    if ($null -eq $data -or -not $data.PSObject.Properties['data'] -or $data.data -isnot [Array]) {
        throw 'MODELS_RESPONSE_INVALID'
    }
    $ids = @($data.data | Where-Object {
        $_ -and $_.PSObject.Properties['id'] -and $_.id -is [string] -and
        $_.id -cmatch '^gpt-[0-9][a-z0-9._-]{0,79}$'
    } | ForEach-Object { $_.id } | Sort-Object -Unique)
    # Image-only models use a different protocol and are not chat selections.
    if ($ids.Count -eq 0) { throw 'MODELS_NONE_AVAILABLE' }
    if ($ids.Count -gt 64) { throw 'MODELS_RESPONSE_INVALID' }
    $order = @('gpt-6.1-sol', 'gpt-6-astra', 'gpt-6-sol', 'gpt-6-luna', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna', 'gpt-5.5')
    return @($order | Where-Object { $_ -in $ids }) + @($ids | Where-Object { $_ -notin $order })
}

function Set-RealyuPrivateFile([string]$Path) {
    $acl = New-Object Security.AccessControl.FileSecurity
    $acl.SetAccessRuleProtection($true, $false)
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().User
    $system = New-Object Security.Principal.SecurityIdentifier('S-1-5-18')
    foreach ($identity in @($user, $system)) {
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($identity, 'FullControl', 'Allow')
        $acl.AddAccessRule($rule)
    }
    if ([IO.File].GetMethod('SetAccessControl')) { [IO.File]::SetAccessControl($Path, $acl) }
    else { [IO.FileSystemAclExtensions]::SetAccessControl((New-Object IO.FileInfo($Path)), $acl) }
}

function Test-RealyuConfigJson([string]$Json) {
    # The standard reader exposes JSON object members as direct XML children.
    # ConvertFrom-Json alone silently discards repeated property names.
    Add-Type -AssemblyName System.Runtime.Serialization
    $reader = $null
    $objects = @{}
    try {
        $reader = [Runtime.Serialization.Json.JsonReaderWriterFactory]::CreateJsonReader(
            [Text.Encoding]::UTF8.GetBytes($Json), [Xml.XmlDictionaryReaderQuotas]::Max)
        while ($reader.Read()) {
            if ($reader.NodeType -eq [Xml.XmlNodeType]::Element) {
                $depth = $reader.Depth
                if ($objects.ContainsKey($depth - 1)) {
                    $name = $reader.LocalName
                    if ($reader.NamespaceURI -eq 'item') { $name = $reader.GetAttribute('item') }
                    if (-not $objects[$depth - 1].Add($name)) { throw 'CONFIG_JSON_INVALID' }
                }
                $objects.Remove($depth)
                if ($reader.GetAttribute('type') -eq 'object') {
                    $names = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
                    # The reader maps a leading __type member to an XML attribute.
                    if ($null -ne $reader.GetAttribute('__type')) { $null = $names.Add('__type') }
                    $objects[$depth] = $names
                }
            } elseif ($reader.NodeType -eq [Xml.XmlNodeType]::EndElement) {
                $objects.Remove($reader.Depth)
            }
        }
    } catch { throw 'CONFIG_JSON_INVALID' }
    finally { if ($null -ne $reader) { $reader.Dispose() } }
}

function Test-RealyuConfigPath([string]$Path) {
    $parent = $Path
    while ($parent) {
        if ((Test-Path -LiteralPath $parent) -and ((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'CONFIG_LINK_UNSUPPORTED'
        }
        $parent = [IO.Path]::GetDirectoryName($parent)
    }
}

function Test-RealyuConfigUnchanged([string]$Path, [byte[]]$BeforeBytes) {
    Test-RealyuConfigPath $Path
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw 'CONFIG_CHANGED_RETRY' }
    $current = [IO.File]::ReadAllBytes($Path)
    if ([Convert]::ToBase64String($current) -cne [Convert]::ToBase64String($BeforeBytes)) { throw 'CONFIG_CHANGED_RETRY' }
}

function Install-RealyuWorkBuddy([string]$Key, [string]$ConfigDirectory) {
    $null = Get-RealyuWorkBuddyInstall -Quiet
    if ($Key -cnotmatch '^sk-[A-Za-z0-9_-]{16,256}$') { throw 'KEY_FORMAT_INVALID' }
    $directory = [IO.Path]::GetFullPath($ConfigDirectory)
    # Never follow a redirected configuration tree or configuration file.
    Test-RealyuConfigPath $directory
    $null = New-Item -ItemType Directory -Path $directory -Force
    $lockPath = Join-Path $directory '.realyu-config.lock'
    try {
        # CreateNew refuses an existing file/link; DeleteOnClose also cleans up on process exit.
        $configLock = New-Object IO.FileStream($lockPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::ReadWrite,
            [IO.FileShare]::None, 1, [IO.FileOptions]::DeleteOnClose)
    } catch { throw 'CONFIG_BUSY' }
    try {
        Test-RealyuConfigPath $directory
        $path = Join-Path $directory 'models.json'
        $before = $null
        $beforeBytes = $null
        $document = $null
        $arrayFormat = $true
        $models = @()
        if (Test-Path -LiteralPath $path) {
            $file = Get-Item -LiteralPath $path -Force
            if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 1MB) { throw 'CONFIG_UNSUPPORTED' }
            $beforeBytes = [IO.File]::ReadAllBytes($path)
            $snapshotReader = New-Object IO.StreamReader([IO.MemoryStream]::new($beforeBytes))
            try { $before = $snapshotReader.ReadToEnd() } finally { $snapshotReader.Dispose() }
            Test-RealyuConfigJson $before
            try { $document = ConvertFrom-Json -InputObject $before } catch { throw 'CONFIG_JSON_INVALID' }
            if ($before.TrimStart().StartsWith('[')) {
                if ($null -ne $document) { $models = @($document) }
            }
            elseif ($before.TrimStart().StartsWith('{') -and $document.PSObject.Properties['models'] -and $document.models -is [Array]) {
                $arrayFormat = $false
                $models = @($document.models)
                if ($document.PSObject.Properties['availableModels'] -and $document.availableModels -isnot [Array]) { throw 'CONFIG_UNSUPPORTED' }
            } else { throw 'CONFIG_UNSUPPORTED' }
            foreach ($model in $models) {
                if ($null -eq $model -or -not $model.PSObject.Properties['id'] -or $model.id -isnot [string]) { throw 'CONFIG_UNSUPPORTED' }
            }
        }
        $endpoint = 'https://api.realyu.fun/v1/chat/completions'
        Test-RealyuWorkBuddyKey $Key
        $ids = @(Get-RealyuWorkBuddyModels $Key)
        if ($ids.Count -eq 0) { throw 'MODELS_NONE_AVAILABLE' }
        foreach ($id in $ids) {
            $matchedModels = @($models | Where-Object { $_.id -eq $id -or $_.id -eq ('custom-local:' + $id) })
            if ($matchedModels.Count -gt 1) { throw 'CONFIG_DUPLICATE_MODEL' }
            if ($matchedModels.Count -eq 1 -and (-not $matchedModels[0].PSObject.Properties['url'] -or $matchedModels[0].url -ne $endpoint)) {
                throw 'CONFIG_MODEL_CONFLICT'
            }
            $label = $id
            $model = [pscustomobject]@{
                id = $id; name = $label; vendor = 'RealYu API'
                url = $endpoint; apiKey = $Key
                maxInputTokens = 200000; maxOutputTokens = 4096
                supportsToolCall = $true; supportsImages = $false
                supportsReasoning = $false; useCustomProtocol = $false
            }
            if ($matchedModels.Count -eq 1) {
                foreach ($property in $model.PSObject.Properties) {
                    $matchedModels[0] | Add-Member -MemberType NoteProperty -Name $property.Name -Value $property.Value -Force
                }
            } else { $models += $model }
        }
        $managedIds = @($ids) + @($ids | ForEach-Object { 'custom-local:' + $_ })
        $others = @($models | Where-Object { $_.id -notin $managedIds })
        $ordered = @(foreach ($id in $ids) {
            $models | Where-Object { $_.id -eq $id -or $_.id -eq ('custom-local:' + $id) }
        })
        $models = $others + $ordered
        if ($arrayFormat) { $json = ConvertTo-Json -InputObject @($models) -Depth 64 }
        else {
            $document.models = @($models)
            if ($document.PSObject.Properties['availableModels'] -and $document.availableModels.Count -gt 0) {
                foreach ($id in $ids) {
                    if ($id -notin $document.availableModels) { $document.availableModels += $id }
                }
            }
            $json = ConvertTo-Json -InputObject $document -Depth 64
        }
        $null = New-Item -ItemType Directory -Path $directory -Force
        $temp = Join-Path $directory ('.realyu-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $backup = $null
        try {
            $null = New-Item -ItemType File -Path $temp
            Set-RealyuPrivateFile $temp
            [IO.File]::WriteAllText($temp, $json + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
            if ($null -ne $before) {
                Test-RealyuConfigUnchanged $path $beforeBytes
                $backup = Join-Path $directory ('models.realyu-backup-' + [Guid]::NewGuid().ToString('N') + '.json')
                $null = New-Item -ItemType File -Path $backup
                Set-RealyuPrivateFile $backup
                [IO.File]::WriteAllBytes($backup, $beforeBytes)
                Set-RealyuPrivateFile $path
                Test-RealyuConfigUnchanged $path $beforeBytes
                # The separately created backup retains the exact initial snapshot.
                [IO.File]::Replace($temp, $path, [NullString]::Value)
            } else {
                Test-RealyuConfigPath $path
                [IO.File]::Move($temp, $path)
            }
            # No fallible post-write work: an atomic replacement either succeeds or preserves the original.
            return [pscustomobject]@{ Models = $ids; BackupCreated = ($null -ne $backup) }
        } finally {
            if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
        }
    } finally { $configLock.Dispose() }
}

if ($MyInvocation.InvocationName -ne '.') {
    $key = $null
    try {
        $null = Get-RealyuWorkBuddyInstall
        $key = $ApiKey
        if (-not $key) {
            $secure = Read-Host 'RealYu API Key' -AsSecureString
            $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
            try { $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
            finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer); $secure.Dispose() }
        }
        $config = Join-Path $env:USERPROFILE '.workbuddy'
        if ($env:WORKBUDDY_CONFIG_DIR) { $config = $env:WORKBUDDY_CONFIG_DIR }
        elseif ($env:CODEBUDDY_CONFIG_DIR) { $config = $env:CODEBUDDY_CONFIG_DIR }
        $result = Install-RealyuWorkBuddy -Key $key -ConfigDirectory $config
        Write-Host ('Setup complete. Imported ' + $result.Models.Count + ' models. Reopen WorkBuddy and select a RealYu API model.')
    } catch {
        $code = $_.Exception.Message
        if ($code -notmatch '^(WORKBUDDY|CONFIG|KEY|MODELS)_[A-Z_]+$') { $code = 'CONFIG_WRITE_FAILED' }
        Write-Host ('Setup failed: ' + $code)
        Write-Host 'Check the installed version, API key, network and configuration. No credentials were printed.'
        throw $code
    } finally { $key = $null; $ApiKey = $null }
}
