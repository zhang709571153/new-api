﻿. (Join-Path $PSScriptRoot 'common.ps1')
Add-Type -AssemblyName System.Drawing
Add-Type -Path (Join-Path $PSScriptRoot 'image.cs') -ReferencedAssemblies 'System.Web.Extensions.dll','System.Drawing.dll'
$imageBase = 'https://api.realyu.fun/v1'
$imageStatus = 'https://api.realyu.fun/api/status'
$imageKeyCheck = 'https://api.realyu.fun/api/client/key-check'
$tools = Parse-Json ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'tools.json'),$utf8))
$imageHome = if ($env:REALYU_CODEX_HOME) { $env:REALYU_CODEX_HOME } elseif ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
function Image-Key {
    $script:imageCredentialSource='codex_auth'
    $script:imageEnvironmentOverrideIgnored=$false
    if ($env:REALYU_WORKBUDDY_HOME) {
        # Use the same credentials as WorkBuddy chat; inherited shell keys must not override this connection.
        $script:imageCredentialSource='workbuddy_models'
        $script:imageEnvironmentOverrideIgnored=-not [string]::IsNullOrEmpty($env:REALYU_API_KEY)
        $modelsPath=Join-Path $env:REALYU_WORKBUDDY_HOME 'models.json';Assert-LocalPath $modelsPath
        $document=Parse-Json ([IO.File]::ReadAllText($modelsPath,$utf8))
        $models=if ($document -is [Array]) { $document } else { $document['models'] }
        $keys=@($models | Where-Object { $_['url'] -ceq ($imageBase+'/chat/completions') } | ForEach-Object { $_['apiKey'] } | Select-Object -Unique)
        if ($keys.Count -ne 1 -or $keys[0] -cnotmatch '^sk-[A-Za-z0-9_-]{16,256}$') { throw 'IMAGE_CONFIG_INVALID' }
        return $keys[0]
    }
    if ($env:REALYU_API_KEY -cmatch '^sk-[A-Za-z0-9_-]{16,256}$') { $script:imageCredentialSource='environment';return $env:REALYU_API_KEY }
    Assert-LocalPath $imageHome
    $savedPath=Join-Path $PSScriptRoot 'codex-path.txt'
    $exe=if ([IO.File]::Exists($savedPath)) { [IO.File]::ReadAllText($savedPath,$utf8) } else { $null }
    if (-not $exe -or -not [IO.File]::Exists($exe)) {
        $probe=Join-Path $imageHome ('realyu-runtime/discovery-'+[Guid]::NewGuid().ToString('N'))
        New-PrivateDirectory $probe
        try { $exe=Find-Codex $probe } finally {
            Assert-LocalPath $probe
            $allowed=[IO.Path]::GetFullPath((Join-Path $imageHome 'realyu-runtime'))+[IO.Path]::DirectorySeparatorChar
            $resolved=[IO.Path]::GetFullPath($probe)
            if (-not $resolved.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)) { throw 'PATH_UNSAFE' }
            [IO.Directory]::Delete($resolved,$true)
        }
    }
    $rpc=Open-Rpc $exe $imageHome
    try { $config=(Call-Rpc $rpc 'config/read' @{includeLayers=$false})['config'] } finally { $rpc.Dispose() }
    $provider=$config['model_providers'][$config['model_provider']]
    if ($provider['base_url'].TrimEnd('/') -cne $imageBase -or $provider['requires_openai_auth'] -ne $true) { throw 'IMAGE_CONFIG_INVALID' }
    $authPath=Join-Path $imageHome 'auth.json';Assert-LocalPath $authPath
    $auth=Parse-Json ([IO.File]::ReadAllText($authPath,$utf8))
    if ($auth['OPENAI_API_KEY'] -cnotmatch '^sk-[A-Za-z0-9_-]{16,256}$') { throw 'IMAGE_KEY_MISSING' }
    return $auth['OPENAI_API_KEY']
}
function Image-Output {
    $output=if ($env:REALYU_IMAGE_OUTPUT_DIR) { [IO.Path]::GetFullPath($env:REALYU_IMAGE_OUTPUT_DIR) } else { Join-Path $imageHome 'generated_images\realyu' }
    Assert-LocalPath $output; $null=[IO.Directory]::CreateDirectory($output)
    $probe=Join-Path $output ('.write-check-'+[Guid]::NewGuid().ToString('N'))
    $stream=[IO.File]::Open($probe,'CreateNew','Write','None');$stream.Dispose();[IO.File]::Delete($probe)
    return $output
}
function Diagnose-Images {
    $checks=[Collections.Generic.List[object]]::new();$key=$null
    foreach ($stage in @('credentials','output_directory','gateway','key_check')) {
        try {
            switch ($stage) {
                'credentials' { $key=Image-Key }
                'output_directory' { $null=Image-Output }
                'gateway' { $response=Parse-Json ([RealyuNative.Images]::Check($imageStatus,$null));if ($response['success'] -ne $true) { throw 'IMAGE_RESPONSE_INVALID' } }
                'key_check' { if (-not $key) { throw 'IMAGE_KEY_MISSING' };$response=Parse-Json ([RealyuNative.Images]::Check($imageKeyCheck,$key));if ($response['code'] -ne $true) { throw 'IMAGE_KEY_REJECTED' } }
            }
            $checks.Add(@{stage=$stage;status='passed'})
        } catch { $checks.Add(@{stage=$stage;status='failed';code=(Error-Code $_ 'IMAGE_CHECK_FAILED')}) }
    }
    return @{content=@(@{type='text';text=(To-Json @{proxy_policy='windows_system';version='1.4.32';credential_source=$script:imageCredentialSource;environment_override_ignored=$script:imageEnvironmentOverrideIgnored;generation_requests=0;checks=$checks.ToArray();all_passed=(@($checks | Where-Object {$_.status -ne 'passed'}).Count -eq 0)})})}
}
function Invoke-Image([string]$Name,$Arguments) {
    [RealyuNative.Images]::RequestId=$null
    $diagnostic=@{proxy_policy='windows_system';version='1.4.32';id=[Guid]::NewGuid().ToString('N');stage='input';request_attempted=$false;image_received=$false}
    try {
        $prompt=$Arguments['prompt'];$quality=$Arguments['quality'];$size=$Arguments['size']
        if ($null -eq $quality) { $quality='auto' };if ($null -eq $size) { $size='auto' }
        if ($prompt -isnot [string] -or -not $prompt.Trim() -or $prompt.Length -gt 16000 -or $quality -notin @('auto','low','medium','high') -or $size -notin $tools[0]['inputSchema']['properties']['size']['enum']) { throw 'IMAGE_INPUT_INVALID' }
        $content=@(@{type='input_text';text=$prompt})
        if ($Name -eq 'edit_image') {
            $path=$Arguments['image_path']
            if ($path -isnot [string] -or -not [IO.Path]::IsPathRooted($path)) { throw 'IMAGE_PATH_INVALID' }
            Assert-LocalPath $path
            $stream=[IO.File]::OpenRead($path)
            try { if ($stream.Length -gt 20971520) { throw 'IMAGE_INPUT_TOO_LARGE' };$memory=[IO.MemoryStream]::new();$stream.CopyTo($memory);$bytes=$memory.ToArray();$memory.Dispose() } finally { $stream.Dispose() }
            [RealyuNative.Images]::ValidateInput($bytes)
            $content+=@{type='input_image';image_url=('data:'+ [RealyuNative.Images]::Mime($bytes)+';base64,'+[Convert]::ToBase64String($bytes))}
        }
        $diagnostic.stage='credentials';$key=Image-Key
        $diagnostic.stage='output_directory';$output=Image-Output
        $body=@{model='gpt-5.6-luna';instructions='Generate or edit the requested image.';input=@(@{role='user';content=$content});tools=@(@{type='image_generation';model='gpt-image-2';quality=$quality;size=$size;output_format='png'});tool_choice=@{type='image_generation'};stream=$true;store=$false}
        $diagnostic.stage='connection';$diagnostic.request_attempted=$true
        $reply=[RealyuNative.Images]::Generate(($imageBase+'/responses'),$key,(To-Json $body));$key=$null
        $diagnostic.stage='response';$bytes=[Convert]::FromBase64String($reply.Encoded)
        $files=[RealyuNative.Images]::Preview($bytes)
        $diagnostic.image_received=$true;$diagnostic.stage='save'
        $name=[Guid]::NewGuid().ToString('N');$original=Join-Path $output ($name+'.png');$preview=Join-Path $output ($name+'-preview.png')
        Write-Atomic $original $bytes;Write-Atomic $preview $files.Preview
        # Markdown treats backslash-dot as an escape, corrupting the separator before .codex.
        # Forward slashes also work with Windows file APIs; angle brackets preserve spaces.
        $originalPath=$original.Replace('\','/');$previewPath=$preview.Replace('\','/')
        $metadata=@{file=$originalPath;original_file=$originalPath;preview_file=$previewPath;display_markdown=('![Generated image](<'+$previewPath+'>)');original_markdown=('[Original image](<'+$originalPath+'>)');bytes=$bytes.Length;preview_bytes=$files.Preview.Length;model='gpt-image-2';note='Display the image using display_markdown verbatim. The attached image is a small preview. Use original_file for sharing and further edits.'}
        if ($reply.RequestId -cmatch '^[0-9]{14}[A-Za-z0-9]{8,50}$') { $metadata.request_id=$reply.RequestId }
        return @{content=@(@{type='text';text=(To-Json $metadata)},@{type='image';mimeType='image/png';data=[Convert]::ToBase64String($files.Preview)})}
    } catch {
        $diagnostic.code=Error-Code $_ 'IMAGE_CLIENT_ERROR'
        if ($diagnostic.stage -ne 'input') { $diagnostic.credential_source=$script:imageCredentialSource;$diagnostic.environment_override_ignored=$script:imageEnvironmentOverrideIgnored }
        if ($diagnostic.stage -eq 'connection') {
            if ([RealyuNative.Images]::TransportStage) { $diagnostic.stage=[RealyuNative.Images]::TransportStage }
            $diagnostic.http_status=[RealyuNative.Images]::HttpStatus
            $diagnostic.received_bytes=[RealyuNative.Images]::ReceivedBytes
            if ([RealyuNative.Images]::LastEvent) { $diagnostic.last_event=[RealyuNative.Images]::LastEvent }
            if ([RealyuNative.Images]::UpstreamErrorCode) { $diagnostic.upstream_error_code=[RealyuNative.Images]::UpstreamErrorCode }
        }
        if ([RealyuNative.Images]::RequestId -cmatch '^[0-9]{14}[A-Za-z0-9]{8,50}$') { $diagnostic.request_id=[RealyuNative.Images]::RequestId }
        $message=Explain-Error $diagnostic.code
        return @{isError=$true;content=@(@{type='text';text=($message[0]+' 下一步：'+$message[1]+' No automatic retry was made. Diagnostic: '+(To-Json $diagnostic))})}
    } finally { $key=$null }
}
$initialized=$false
while ($null -ne ($line=[Console]::ReadLine())) {
    $request=$null
    try {
        if ($line.Length -gt 1048576) { throw 'MCP_REQUEST_TOO_LARGE' }
        $request=Parse-Json $line
        if ($request -isnot [Collections.IDictionary] -or -not $request.ContainsKey('id')) { continue }
        $method=$request['method'];$params=$request['params'];$result=$null
        switch ($method) {
            'initialize' {
                $protocol=$params['protocolVersion'];if ($protocol -notin @('2024-11-05','2025-03-26','2025-06-18','2025-11-25')) { $protocol='2025-11-25' }
                $result=@{protocolVersion=$protocol;capabilities=@{tools=@{listChanged=$false}};serverInfo=@{name='image-generation';version='1.4.32'}};$initialized=$true
            }
            'ping' { $result=@{} }
            'tools/list' { if (-not $initialized) { throw 'MCP_NOT_INITIALIZED' };$result=@{tools=$tools} }
            'tools/call' {
                if (-not $initialized) { throw 'MCP_NOT_INITIALIZED' }
                switch ($params['name']) {
                    'diagnose_image' { $result=Diagnose-Images }
                    'generate_image' { $result=Invoke-Image $params['name'] $params['arguments'] }
                    'edit_image' { $result=Invoke-Image $params['name'] $params['arguments'] }
                    default { throw 'MCP_METHOD_UNKNOWN' }
                }
            }
            default { throw 'MCP_METHOD_UNKNOWN' }
        }
        [Console]::WriteLine((To-Json @{jsonrpc='2.0';id=$request['id'];result=$result}))
    } catch {
        $code=if ((Error-Code $_) -eq 'MCP_METHOD_UNKNOWN') { -32601 } else { -32600 }
        [Console]::WriteLine((To-Json @{jsonrpc='2.0';id=$(if ($request) {$request['id']} else {$null});error=@{code=$code;message='Invalid or unsupported request'}}))
    }
}
