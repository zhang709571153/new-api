﻿param([switch]$FunctionsOnly,[ValidateSet('codex','workbuddy')][string]$Product='codex')
if (-not $FunctionsOnly) { [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false); Write-Host '[0/4] 正在初始化系统组件（首次运行可能稍慢）…' }
. (Join-Path $PSScriptRoot 'common.ps1')
$baseUrl = 'https://api.realyu.fun/v1'
$keyCheckUrl = 'https://api.realyu.fun/api/client/key-check'
$diagnosticsUrl = 'https://api.realyu.fun/api/client/diagnostics'
$version = '1.4.32'
$ownedRoot = @('model_provider','model','openai_base_url','model_reasoning_effort','service_tier','cli_auth_credentials_store','profile','model_catalog_json')

function Validate-Key([string]$Key) {
    if ($Key -cnotmatch '^sk-[A-Za-z0-9_-]{16,256}$') { throw 'KEY_FORMAT_INVALID' }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    for ($attempt=0; $attempt -lt 2; $attempt++) {
        $response = $null
        try {
            $request = [Net.HttpWebRequest]::Create($keyCheckUrl)
            $request.AllowAutoRedirect = $false
            $request.Timeout = 15000; $request.ReadWriteTimeout = 15000
            $request.UserAgent = 'Realyu-Setup/1.4.32'
            $request.Headers['Authorization'] = 'Bearer ' + $Key
            try { $response = $request.GetResponse() }
            catch [Net.WebException] {
                if ($_.Exception.Response) { $response = $_.Exception.Response }
                elseif ($attempt -eq 0 -and $_.Exception.Status -in @('Timeout','ConnectFailure','ConnectionClosed','ReceiveFailure','SendFailure')) { Start-Sleep -Milliseconds 500; continue }
                else { throw 'KEY_NETWORK_ERROR' }
            }
            $script:report.http_status = [int]$response.StatusCode
            switch ([int]$response.StatusCode) {
                200 { }
                401 { throw 'KEY_REJECTED' }
                403 { throw 'KEY_ACCESS_DENIED' }
                429 { throw 'KEY_RATE_LIMITED' }
                default { throw 'KEY_HTTP_ERROR' }
            }
            $stream = $response.GetResponseStream()
            $buffer = [byte[]]::new(1048577)
            $count=0
            while ($count -lt $buffer.Length) {
                $read=$stream.Read($buffer,$count,$buffer.Length-$count)
                if ($read -eq 0) { break }
                $count += $read
            }
            if ($count -gt 1048576 -or ($response.ContentLength -ge 0 -and $count -ne $response.ContentLength)) { throw 'KEY_RESPONSE_INVALID' }
            try { $data = Parse-Json ($utf8.GetString($buffer,0,$count)) } catch { throw 'KEY_RESPONSE_INVALID' }
            $usage = $data['data']
            if ($data['code'] -isnot [bool] -or -not $data['code'] -or $usage -isnot [Collections.IDictionary] -or $usage['object'] -ne 'token_usage' -or $usage['unlimited_quota'] -isnot [bool] -or $usage['expires_at'] -isnot [ValueType] -or $usage['expires_at'] -is [bool] -or $usage['total_available'] -isnot [ValueType] -or $usage['total_available'] -is [bool]) { throw 'KEY_RESPONSE_INVALID' }
            if ($usage['expires_at'] -gt 0 -and $usage['expires_at'] -lt [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) { throw 'KEY_EXPIRED' }
            if (-not $usage['unlimited_quota'] -and $usage['total_available'] -le 0) { Write-Host '密钥有效，当前可用额度为零；配置可继续。' }
            return
        } finally { if ($response) { $response.Dispose() } }
    }
    throw 'KEY_NETWORK_ERROR'
}

function Unowned-Config($Value,[bool]$ChangedLoginPreference=$false) {
    $copy = Parse-Json (To-Json $Value)
    foreach ($name in $ownedRoot) { $null=$copy.Remove($name) }
    if ($ChangedLoginPreference) { $null=$copy.Remove('forced_login_method') }
    foreach ($pair in @(@('model_providers','realyu'),@('mcp_servers','realyu_images'),@('mcp_servers','image_generation'))) {
        if ($copy.ContainsKey($pair[0])) {
            $null=$copy[$pair[0]].Remove($pair[1])
            if ($copy[$pair[0]].Count -eq 0) { $null=$copy.Remove($pair[0]) }
        }
    }
    return ,$copy
}
function Equal-Value($Left,$Right) {
    if ($null -eq $Left -or $null -eq $Right) { return $null -eq $Left -and $null -eq $Right }
    if ($Left -is [Collections.IDictionary]) {
        if ($Right -isnot [Collections.IDictionary] -or $Left.Count -ne $Right.Count) { return $false }
        foreach ($name in $Left.Keys) { if (-not $Right.ContainsKey($name) -or -not (Equal-Value $Left[$name] $Right[$name])) { return $false } }
        return $true
    }
    if ($Left -is [Array]) {
        if ($Right -isnot [Array] -or $Left.Count -ne $Right.Count) { return $false }
        for ($i=0;$i -lt $Left.Count;$i++) { if (-not (Equal-Value $Left[$i] $Right[$i])) { return $false } }
        return $true
    }
    return $Left -ceq $Right
}
function Get-UserConfig($Read) {
    foreach ($layer in $Read['layers']) { if ($layer['name']['type'] -eq 'user') { return ,$layer['config'] } }
    return ,@{}
}
function Assert-OwnedImage($Config,[string]$Directory) {
    $existing = $Config['mcp_servers']['image_generation']
    if ($null -eq $existing) { return }
    if ($existing['url'] -or $existing['env']['REALYU_CODEX_HOME'] -ne $Directory) { throw 'CONFIG_IMAGE_TOOL_CONFLICT' }
    $command = [string]$existing['command']; $arguments = @($existing['args'])
    $pythonOwned = (Equal-Value $arguments @('-I','-B','-X','utf8',(Join-Path $Directory 'realyu_images.py')))
    $exeOwned = ($arguments.Count -eq 1 -and $arguments[0] -eq 'images' -and [IO.Path]::GetFileName($command) -eq 'realyu-client.exe' -and ($command -eq (Join-Path $Directory 'realyu-client.exe') -or [IO.Path]::GetDirectoryName([IO.Path]::GetDirectoryName([IO.Path]::GetDirectoryName($command))) -eq (Join-Path $Directory 'realyu-runtime')))
    $psOwned = ([IO.Path]::GetFileName($command) -eq 'powershell.exe' -and $arguments.Count -eq 5 -and (Equal-Value $arguments[0..3] @('-NoProfile','-ExecutionPolicy','Bypass','-File')) -and $arguments[4].StartsWith((Join-Path $Directory 'realyu-runtime\scripts\'),[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($arguments[4]) -eq 'realyu-images.ps1')
    if (-not ($pythonOwned -or $exeOwned -or $psOwned)) { throw 'CONFIG_IMAGE_TOOL_CONFLICT' }
}

function Resume-Offline($Client,$Item,$Overrides=@{}) {
    $params = @{includeLayers=$false}
    if ($Item['cwd']) { $params.cwd=$Item['cwd'] }
    $effective = (Call-Rpc $Client 'config/read' $params)['config']
    $disabled=@{}; $providers=@{}
    if ($effective['mcp_servers']) { foreach ($name in $effective['mcp_servers'].Keys) { $disabled[$name]=@{enabled=$false;required=$false} } }
    if ($effective['model_providers']) { foreach ($name in $effective['model_providers'].Keys) { $providers[$name]=@{base_url='http://127.0.0.1:1/v1';supports_websockets=$false} } }
    $params=@{threadId=$Item['id'];excludeTurns=$true;config=@{mcp_servers=$disabled;'features.shell_snapshot'=$false;model_providers=$providers;openai_base_url='http://127.0.0.1:1/v1'}}
    foreach ($name in $Overrides.Keys) { $params[$name]=$Overrides[$name] }
    return ,(Call-Rpc $Client 'thread/resume' $params)
}
function Read-Threads($Client,[string]$Directory,[switch]$Archived) {
    $items=@{}; $cursor=$null; $cursors=@{}
    foreach ($archivedState in $(if ($Archived) { @($false,$true) } else { @($false) })) {
        $cursor=$null
        do {
            $page=Call-Rpc $Client 'thread/list' @{archived=$archivedState;limit=100;cursor=$cursor;sortKey='created_at';sortDirection='asc';modelProviders=@();sourceKinds=@('cli','vscode','exec','appServer','subAgent','subAgentReview','subAgentCompact','subAgentThreadSpawn','subAgentOther','unknown')}
            foreach ($item in $page['data']) { if ($items.ContainsKey($item['id'])) { throw 'SESSIONS_CHANGED' }; $item['archived']=$archivedState; $items[$item['id']]=$item }
            $cursor=$page['nextCursor']
            if ($cursor) { if ($cursors.ContainsKey($cursor)) { throw 'SESSIONS_RPC_FAILED' }; $cursors[$cursor]=$true }
        } while ($cursor)
    }
    $databases=@(Get-ChildItem -LiteralPath $Directory -Filter 'state_*.sqlite' -File | Sort-Object { if ($_.BaseName -match 'state_(\d+)$') { [int]$Matches[1] } else { -1 } })
    $script:archivedCount=0
    if ($databases.Count) {
        $database=$databases[-1].FullName; Assert-LocalPath $database
        foreach ($row in [RealyuNative.Sqlite]::Read($database)) {
            if ($row.Archived) { $script:archivedCount++; if (-not $Archived) { $null=$items.Remove($row.Id);continue } }
            if (-not $items.ContainsKey($row.Id)) {
                try {
                    $item=(Call-Rpc $Client 'thread/read' @{threadId=$row.Id;includeTurns=$false})['thread']
                    if ($item['id'] -ne $row.Id) { throw 'SESSIONS_THREAD_MISMATCH' }
                } catch { $item=@{id=$row.Id;read_error=(Error-Code $_ 'SESSIONS_RPC_FAILED')} }
                $item['archived']=$row.Archived; $items[$row.Id]=$item
            }
        }
    }
    return ,$items
}
function Session-Parent($Item) {
    $source=$Item['source']; $parent=$Item['parentThreadId']
    if ($source -is [Collections.IDictionary] -and $source['subAgent'] -is [Collections.IDictionary] -and $source['subAgent']['thread_spawn'] -is [Collections.IDictionary] -and $parent -and $source['subAgent']['thread_spawn']['parent_thread_id'] -eq $parent) { return $parent }
    return $null
}
function Backup-Rollout([string]$Directory,[string]$Backup,$Item) {
    if (-not $Item['path']) { throw 'SESSIONS_BACKUP_FAILED' }
    $path=[IO.Path]::GetFullPath($Item['path'])
    if ($path.StartsWith('\\?\UNC\',[StringComparison]::OrdinalIgnoreCase)) { $path='\\'+$path.Substring(8) }
    elseif ($path.StartsWith('\\?\')) { $path=$path.Substring(4) }
    $path=[IO.Path]::GetFullPath($path)
    $prefix=$Directory.TrimEnd('\')+'\'
    if (-not $path.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'SESSIONS_PATH_UNSAFE' }
    Assert-LocalPath $path
    $target=Join-Path $Backup ('sessions\'+$path.Substring($prefix.Length))
    Assert-LocalPath $target
    # The backup ID can push an otherwise valid rollout path past MAX_PATH in PS5.1.
    $sourceNative=if ($path.StartsWith('\\')) { '\\?\UNC\'+$path.Substring(2) } else { '\\?\'+$path }
    $targetNative=if ($target.StartsWith('\\')) { '\\?\UNC\'+$target.Substring(2) } else { '\\?\'+$target }
    $null=[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($targetNative))
    $before=[IO.FileInfo]::new($sourceNative)
    $size=$before.Length; $time=$before.LastWriteTimeUtc.Ticks
    [IO.File]::Copy($sourceNative,$targetNative,$false)
    $after=[IO.FileInfo]::new($sourceNative)
    if ($size -ne $after.Length -or $time -ne $after.LastWriteTimeUtc.Ticks) { throw 'SESSIONS_CHANGED' }
}
function Migrate-Sessions([string]$Directory,[string]$Exe,[string]$Backup,[string]$Probe) {
    $sessionReport=@{status='scanning';migrated=0;already_current=0;failed=0;compatible_children=0;skipped_children=0;skipped_archived=0}
    $script:report.sessions=$sessionReport
    Assert-SessionsIdle $Directory
    $journalPath=Join-Path $Directory 'realyu-session-migration.json'; Assert-LocalPath $journalPath
    # Verify native persistence and OS writer exclusion in a disposable home first.
    $probeHome=Join-Path $Probe 'session-probe'; New-PrivateDirectory $probeHome
    [IO.File]::WriteAllText((Join-Path $probeHome 'config.toml'),"model_provider=`"realyu`"`nmodel=`"gpt-6-luna`"`n[model_providers.realyu]`nname=`"Offline probe`"`nbase_url=`"http://127.0.0.1:1/v1`"`nwire_api=`"responses`"`nrequires_openai_auth=true`n",$utf8)
    [IO.File]::WriteAllText((Join-Path $probeHome 'auth.json'),'{"OPENAI_API_KEY":"sk-offline-capability-probe"}',$utf8)
    $rpc=Open-Rpc $Exe $probeHome
    try {
        $result=Call-Rpc $rpc 'thread/start' @{cwd=$probeHome;modelProvider='realyu'}
        $null=Call-Rpc $rpc 'thread/settings/update' @{threadId=$result['thread']['id'];model=$result['model']}
        $locked=$false
        try { Assert-SessionsIdle $probeHome } catch { if ((Error-Code $_) -eq 'SESSIONS_BUSY') { $locked=$true } else { throw } }
        if (-not $locked) { throw 'SESSIONS_CLIENT_UNSUPPORTED' }
    } finally { $rpc.Dispose() }
    $rpc=Open-Rpc $Exe $Directory
    try {
        if ([IO.File]::Exists($journalPath)) {
            $journal=Parse-Json ([IO.File]::ReadAllText($journalPath,$utf8))
            if ($journal['schema'] -notin @(1,2) -or $journal['archived'] -isnot [Collections.IDictionary] -or ($journal['schema'] -eq 2 -and ($journal['phase'] -notin @('retry','restore_pending') -or ($journal['phase'] -eq 'retry' -and $journal['archived'].Count)))) { throw 'SESSIONS_JOURNAL_INVALID' }
            foreach ($value in $journal['archived'].Values) { if ($value -isnot [bool]) { throw 'SESSIONS_JOURNAL_INVALID' } }
            if (($journal['schema'] -eq 1 -and $journal['failures'] -isnot [Collections.IDictionary]) -or $journal['phase'] -eq 'restore_pending') {
                $current=Read-Threads $rpc $Directory -Archived
                foreach ($id in $journal['archived'].Keys) { if (-not $current.ContainsKey($id)) { throw 'SESSIONS_CHANGED' } }
                foreach ($id in $journal['archived'].Keys) { if ($journal['archived'][$id] -and -not $current[$id]['archived']) { $null=Call-Rpc $rpc 'thread/archive' @{threadId=$id} } }
                $current=Read-Threads $rpc $Directory -Archived
                foreach ($id in $journal['archived'].Keys) { if (-not $journal['archived'][$id] -and $current[$id]['archived']) { $null=Call-Rpc $rpc 'thread/unarchive' @{threadId=$id} } }
                $current=Read-Threads $rpc $Directory -Archived
                foreach ($id in $journal['archived'].Keys) { if (-not $current.ContainsKey($id) -or $current[$id]['archived'] -ne $journal['archived'][$id]) { throw 'SESSIONS_VERIFY_FAILED' } }
                Write-Atomic $journalPath ($utf8.GetBytes((To-Json @{schema=2;phase='retry';archived=@{}})))
            }
        }
        $items=Read-Threads $rpc $Directory
        $sessionReport.skipped_archived=$script:archivedCount
    } finally { $rpc.Dispose() }
    Assert-SessionsIdle $Directory
    $roots=@($items.Values | Where-Object { -not $_['archived'] -and -not $_['parentThreadId'] -and -not ($_['source'] -is [Collections.IDictionary] -and $_['source'].ContainsKey('subAgent')) } | Sort-Object { $_['createdAt'] },{ $_['id'] })
    $sessionReport.total=$roots.Count
    $failures=@{}; $original=@{}; $changing=@{}
    foreach ($item in $roots) { if ($item['modelProvider'] -ne 'realyu' -or ($journal -and $journal['failures'] -and $journal['failures'].ContainsKey($item['id']))) { $changing[$item['id']]=$true }; if ($item['read_error']) { $failures[$item['id']]=$item['read_error'] } }
    if ($changing.Count) {
        $destination=Join-Path $Backup 'sessions'; $null=[IO.Directory]::CreateDirectory($destination)
        foreach ($database in @(Get-ChildItem -LiteralPath $Directory -File | Where-Object { $_.Name -match '^(state|thread_history)_\d+\.sqlite$' })) { Assert-LocalPath $database.FullName; [RealyuNative.Sqlite]::Backup($database.FullName,(Join-Path $destination $database.Name)) }
    }
    Write-Atomic $journalPath ($utf8.GetBytes((To-Json @{schema=2;phase='retry';archived=@{}})))
    for ($offset=0;$offset -lt $roots.Count;$offset+=10) {
        $last=[Math]::Min($offset+10,$roots.Count)
        $batch=@($roots[$offset..($last-1)])
        foreach ($item in $batch) {
            if ($changing.ContainsKey($item['id']) -and -not $failures.ContainsKey($item['id'])) {
                try { Backup-Rollout $Directory $Backup $item } catch { $failures[$item['id']]=Error-Code $_ 'SESSIONS_BACKUP_FAILED' }
            }
        }
        foreach ($phase in @('read','save','verify')) {
            $rpc=$null
            try {
                foreach ($item in $batch) {
                    $id=$item['id']
                    if ($failures.ContainsKey($id) -or ($phase -ne 'verify' -and -not $changing.ContainsKey($id))) { continue }
                    try {
                        if (-not $rpc) { Assert-SessionsIdle $Directory; $rpc=Open-Rpc $Exe $Directory }
                        $overrides=@{}
                        if ($phase -eq 'save') { $overrides=@{modelProvider='realyu';model=$original[$id]['model']} }
                        $result=Resume-Offline $rpc $item $overrides
                        if ($result['thread']['id'] -ne $id -or -not $result['model']) { throw 'SESSIONS_VERIFY_FAILED' }
                        if ($phase -eq 'read') { $original[$id]=@{model=$result['model'];reasoningEffort=$result['reasoningEffort']} }
                        else {
                            if ($result['modelProvider'] -ne 'realyu') { throw 'SESSIONS_VERIFY_FAILED' }
                            if ($phase -eq 'save') {
                                $params=@{threadId=$id;model=$original[$id]['model']}
                                if ($null -ne $original[$id]['reasoningEffort']) { $params.effort=$original[$id]['reasoningEffort'] }
                                $null=Call-Rpc $rpc 'thread/settings/update' $params
                            } elseif ($original.ContainsKey($id) -and ($result['model'] -ne $original[$id]['model'] -or $result['reasoningEffort'] -ne $original[$id]['reasoningEffort'])) { throw 'SESSIONS_SETTINGS_MISMATCH' }
                        }
                        $null=Call-Rpc $rpc 'thread/unsubscribe' @{threadId=$id}
                    } catch {
                        $failures[$id]=Error-Code $_ 'SESSIONS_RPC_FAILED'
                        if ($rpc) { $rpc.Dispose();$rpc=$null }
                    }
                }
            } finally { if ($rpc) { $rpc.Dispose() } }
            Assert-SessionsIdle $Directory
        }
        foreach ($item in $batch) {
            if ($failures.ContainsKey($item['id'])) { $sessionReport.failed++ }
            else { $item['modelProvider']='realyu'; if ($changing.ContainsKey($item['id'])) { $sessionReport.migrated++ } else { $sessionReport.already_current++ } }
        }
        Write-Atomic $journalPath ($utf8.GetBytes((To-Json @{schema=2;phase='retry';archived=@{};failures=$failures})))
        if ($last -lt $roots.Count -and $last % 50 -eq 0) { Write-Host ("旧会话：已处理 {0}/{1}" -f $last,$roots.Count) }
    }
    foreach ($item in $items.Values) {
        if (-not $item['parentThreadId'] -and -not ($item['source'] -is [Collections.IDictionary] -and $item['source'].ContainsKey('subAgent'))) { continue }
        $node=$item; $seen=@{}; $ready=$false
        while ($node -and -not $seen.ContainsKey($node['id']) -and -not $failures.ContainsKey($node['id'])) {
            $seen[$node['id']]=$true
            if ($node['read_error'] -or $node['modelProvider'] -notin @('openai','realyu')) { break }
            $parent=Session-Parent $node
            if (-not $parent) { $ready=$node['modelProvider'] -eq 'realyu' -and -not $node['parentThreadId'];break }
            $node=$items[$parent]
        }
        if ($ready) { $sessionReport.compatible_children++ } else { $sessionReport.skipped_children++ }
    }
    if ($failures.Count) { $sessionReport.status='partial'; Write-Host '部分旧会话暂未完成，已保留备份；关闭 Codex 后重跑可继续。' }
    else { $sessionReport.status='complete'; [IO.File]::Delete($journalPath) }
    Write-Host ("旧会话处理结束：更新 {0}，已就绪 {1}，未完成 {2}。" -f $sessionReport.migrated,$sessionReport.already_current,$sessionReport.failed)
}

function Install-Connection([string]$Directory,[string]$Exe,[string]$Key,[string]$Work,[string]$Backup) {
    $shadow=Join-Path $Work 'connection'; New-PrivateDirectory $shadow
    $configPath=Join-Path $Directory 'config.toml'; $authPath=Join-Path $Directory 'auth.json'
    foreach ($path in @($configPath,$authPath,(Join-Path $Directory 'realyu-models.json'))) { Assert-LocalPath $path }
    $originalConfig=if ([IO.File]::Exists($configPath)) { [IO.File]::ReadAllBytes($configPath) } else { $null }
    $originalAuth=if ([IO.File]::Exists($authPath)) { [IO.File]::ReadAllBytes($authPath) } else { $null }
    [byte[]]$configBytes=@()
    if ($null -ne $originalConfig) { $configBytes=$originalConfig }
    [IO.File]::WriteAllBytes((Join-Path $shadow 'config.toml'),$configBytes)
    $changedLoginPreference=$false
    $rpc=Open-Rpc $Exe $shadow
    try {
        $beforeRead=Call-Rpc $rpc 'config/read' @{includeLayers=$true}
        $before=Get-UserConfig $beforeRead
        if ($beforeRead['config']['forced_login_method'] -eq 'chatgpt') {
            $origin=$null
            if ($beforeRead['origins']) {
                $entry=$beforeRead['origins']['forced_login_method']
                if ($entry -and $entry['name']) { $origin=$entry['name']['type'] }
            }
            if (-not $origin) { throw 'CONFIG_LOGIN_SOURCE_UNKNOWN' }
            if ($origin -ne 'user' -or $before['forced_login_method'] -ne 'chatgpt') { throw 'CONFIG_LOGIN_POLICY' }
            # Clear only a user-owned preference in the shadow home, then expose any policy beneath it.
            $null=Call-Rpc $rpc 'config/batchWrite' @{filePath=(Join-Path $shadow 'config.toml');edits=@(@{keyPath='forced_login_method';value=$null;mergeStrategy='replace'})}
            $changedLoginPreference=$true
            $rpc.Dispose();$rpc=$null;$rpc=Open-Rpc $Exe $shadow
            $beforeRead=Call-Rpc $rpc 'config/read' @{includeLayers=$true}
            if ($beforeRead['config']['forced_login_method'] -eq 'chatgpt') { throw 'CONFIG_LOGIN_POLICY' }
        }
        if ($before['mcp_servers']) { Assert-OwnedImage $before $Directory }
        $identity=(@('common.ps1','native.cs','image.cs','realyu-images.ps1','tools.json','models.json','errors.json') | ForEach-Object { Get-Sha (Join-Path $PSScriptRoot $_) }) -join ''
        $sha=[Security.Cryptography.SHA256]::Create()
        try { $runtimeHash=[BitConverter]::ToString($sha.ComputeHash($utf8.GetBytes($identity+$Exe))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
        $runtime=Join-Path $Directory "realyu-runtime\scripts\$runtimeHash"
        New-PrivateDirectory $runtime
        $catalogPath=Join-Path $runtime 'models.json'
        if ([IO.File]::Exists($catalogPath) -and (Get-Sha $catalogPath) -ne (Get-Sha (Join-Path $PSScriptRoot 'models.json'))) { throw 'HELPER_CACHE_INVALID' }
        if (-not [IO.File]::Exists($catalogPath)) { Write-Atomic $catalogPath ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'models.json'))) }
        $psExe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $values=@{model_provider='realyu';model='gpt-6-astra';openai_base_url=$baseUrl;model_reasoning_effort='high';service_tier='default';cli_auth_credentials_store='file';profile=$null;model_catalog_json=$catalogPath;'model_providers.realyu'=@{name='RealYu API';base_url=$baseUrl;wire_api='responses';requires_openai_auth=$true};'mcp_servers.realyu_images'=$null;'mcp_servers.image_generation'=@{command=$psExe;args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $runtime 'realyu-images.ps1'));tool_timeout_sec=360;startup_timeout_sec=60;enabled_tools=@('generate_image','edit_image','diagnose_image');env=@{REALYU_CODEX_HOME=$Directory};tools=@{generate_image=@{approval_mode='prompt'};edit_image=@{approval_mode='prompt'};diagnose_image=@{approval_mode='prompt'}}}}
        $edits=@(foreach ($name in $values.Keys) { @{keyPath=$name;value=$values[$name];mergeStrategy='replace'} })
        $null=Call-Rpc $rpc 'config/batchWrite' @{filePath=(Join-Path $shadow 'config.toml');edits=$edits}
        $rpc.Dispose();$rpc=$null;$rpc=Open-Rpc $Exe $shadow
        $afterRead=Call-Rpc $rpc 'config/read' @{includeLayers=$true}
        if (-not (Equal-Value (Unowned-Config $before $changedLoginPreference) (Unowned-Config (Get-UserConfig $afterRead) $changedLoginPreference))) { throw 'CONFIG_MERGE_UNSUPPORTED' }
        if ($afterRead['config']['model_provider'] -ne 'realyu' -or $afterRead['config']['openai_base_url'] -ne $baseUrl -or $afterRead['config']['cli_auth_credentials_store'] -ne 'file') { throw 'CONFIG_LOGIN_POLICY' }
        if ($afterRead['config']['forced_login_method'] -eq 'chatgpt') { throw 'CONFIG_LOGIN_POLICY' }
        $requirements=$null
        try { $requirements=Call-Rpc $rpc 'configRequirements/read' @{} }
        catch { if ((Error-Code $_) -ne 'SESSIONS_CLIENT_UNSUPPORTED') { throw } }
        if ($requirements -and $requirements['requirements']) {
            $allowed=$requirements['requirements']['allowedLoginMethods']
            if ($allowed -is [Array] -and 'api' -notin $allowed) { throw 'CONFIG_LOGIN_POLICY' }
        }
    } finally { if ($rpc) { $rpc.Dispose() } }
    New-PrivateDirectory $runtime
    foreach ($name in @('common.ps1','native.cs','image.cs','realyu-images.ps1','tools.json','errors.json')) {
        $destination=Join-Path $runtime $name; Assert-LocalPath $destination
        if ([IO.File]::Exists($destination)) { if ((Get-Sha $destination) -ne (Get-Sha (Join-Path $PSScriptRoot $name))) { throw 'HELPER_CACHE_INVALID' } }
        else { Write-Atomic $destination ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $name))) }
    }
    Write-Atomic (Join-Path $runtime 'codex-path.txt') ($utf8.GetBytes($Exe))
    # Probe catalog using only the local file; no model requests or credentials.
    $modelProbe=[RealyuNative.ProcessHost]::Run($Exe,[string[]]@('-c',('model_catalog_json='+ (To-Json (Join-Path $PSScriptRoot 'models.json'))),'debug','models'),$shadow,$null,20000)
    if ($modelProbe.Code -ne 0) {
        $rpc=Open-Rpc $Exe $shadow
        try { $null=Call-Rpc $rpc 'config/batchWrite' @{filePath=(Join-Path $shadow 'config.toml');edits=@(@{keyPath='model_catalog_json';value=$null;mergeStrategy='replace'})} } finally { $rpc.Dispose() }
        Write-Host '此 Codex 版本采用内置模型目录；连接配置继续。'
    }
    $login=[RealyuNative.ProcessHost]::Run($Exe,[string[]]@('login','--with-api-key'),$shadow,($Key+"`n"),20000)
    if ($login.Code -ne 0) { throw 'CODEX_LOGIN_FAILED' }
    $auth=Parse-Json ([IO.File]::ReadAllText((Join-Path $shadow 'auth.json'),$utf8))
    if ($auth['OPENAI_API_KEY'] -cne $Key -or $auth['tokens']) { throw 'CODEX_CREDENTIALS_INVALID' }
    # Refuse to overwrite a concurrent edit made while native validation ran.
    foreach ($pair in @(@($configPath,$originalConfig),@($authPath,$originalAuth))) {
        $current=if ([IO.File]::Exists($pair[0])) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($pair[0])) } else { $null }
        $expected=if ($null -ne $pair[1]) { [Convert]::ToBase64String([byte[]]$pair[1]) } else { $null }
        if ($current -cne $expected) { throw 'CONFIG_CHANGED' }
    }
    $snapshots=@{}; $changed=[Collections.Generic.List[string]]::new()
    $targets=@{'config.toml'=[IO.File]::ReadAllBytes((Join-Path $shadow 'config.toml'));'auth.json'=[IO.File]::ReadAllBytes((Join-Path $shadow 'auth.json'));'realyu-models.json'=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'models.json'))}
    foreach ($name in $targets.Keys) {
        $path=Join-Path $Directory $name
        $snapshots[$name]=if ([IO.File]::Exists($path)) { [IO.File]::ReadAllBytes($path) } else { $null }
        if ($null -ne $snapshots[$name]) { [IO.File]::WriteAllBytes((Join-Path $Backup $name),$snapshots[$name]) }
    }
    try {
        foreach ($name in @('realyu-models.json','config.toml','auth.json')) { Write-Atomic (Join-Path $Directory $name) $targets[$name]; $changed.Add($name) }
    } catch {
        $failed=$false
        foreach ($name in $changed) {
            try { if ($null -eq $snapshots[$name]) { [IO.File]::Delete((Join-Path $Directory $name)) } else { Write-Atomic (Join-Path $Directory $name) $snapshots[$name] } }
            catch { $failed=$true }
        }
        if ($failed) { throw 'CONFIG_RESTORE_FAILED' }
        throw 'CONFIG_WRITE_FAILED'
    }
}

if ($FunctionsOnly) { return }
$exitCode=0; $work=$null; $key=$null; $setupLock=$null
$report=@{schema_version=1;id=[Guid]::NewGuid().ToString('N');client_version=$version;platform='win32';architecture=$env:PROCESSOR_ARCHITECTURE;stage='discovery';status='running';elevation='standard'}
$directory=if ($env:CODEX_HOME) { [IO.Path]::GetFullPath($env:CODEX_HOME) } else { Join-Path $env:USERPROFILE '.codex' }
if ($Product -eq 'workbuddy') { $directory=if ($env:WORKBUDDY_CONFIG_DIR) { [IO.Path]::GetFullPath($env:WORKBUDDY_CONFIG_DIR) } elseif ($env:CODEBUDDY_CONFIG_DIR) { [IO.Path]::GetFullPath($env:CODEBUDDY_CONFIG_DIR) } else { Join-Path $env:USERPROFILE '.workbuddy' } }
try {
    $key=[Console]::ReadLine().TrimStart([char]65279)
    if ($key -cnotmatch '^sk-[A-Za-z0-9_-]{16,256}$') { throw 'KEY_FORMAT_INVALID' }
    Assert-LocalPath $directory
    $null=[IO.Directory]::CreateDirectory($directory)
    $private=Join-Path $directory 'realyu-runtime'; New-PrivateDirectory $private
    $lockPath=Join-Path $private 'setup.lock'; Assert-LocalPath $lockPath
    try { $setupLock=[IO.File]::Open($lockPath,'OpenOrCreate','ReadWrite','None') } catch { throw 'SETUP_BUSY' }
    $work=Join-Path $private ('setup-'+$report.id); New-PrivateDirectory $work
    Write-Host '[1/4] 检查已安装的应用（无需 Python 或 Node）…'
    if ($Product -eq 'codex') { $codex=Find-Codex $work; $report.codex_version=$script:codexVersion }
    else { $null=& { . (Join-Path $PSScriptRoot 'workbuddy-config.ps1'); Get-RealyuWorkBuddyInstall }; $report.workbuddy_version=$script:workbuddyVersion; $report.workbuddy_version_policy='advisory' }
    $report.stage='key_validation'; Write-Host '[2/4] 验证密钥…'; Validate-Key $key
    $backup=Join-Path $directory ('realyu-backups\'+$report.id); New-PrivateDirectory $backup
    $report.stage='configuration'; Write-Host '[3/4] 备份并写入连接配置…'
    if ($Product -eq 'codex') { Install-Connection $directory $codex $key $work $backup }
    else { . (Join-Path $PSScriptRoot 'workbuddy-core.ps1'); Install-WorkBuddyConnection $directory $key $backup }
    $key=$null; $report.status='success'; $report.stage='sessions'
    Write-Host '[4/4] 检查旧会话…'
    try { if ($Product -eq 'codex') { Migrate-Sessions $directory $codex $backup $work } }
    catch { $report.status='success_with_warnings';$report.code=Error-Code $_ 'SESSIONS_MIGRATION_FAILED';$report.sessions.status=if ($report.code -eq 'SESSIONS_BUSY') {'deferred'} else {'incomplete'};Write-Host ("连接配置已完成；旧会话暂未完成 [{0}]。请关闭 Codex 后重跑原命令继续。" -f $report.code) }
    if ($report.sessions.status -eq 'partial') { $report.status='success_with_warnings';$report.code='SESSIONS_VERIFY_FAILED' }
    Write-Host ('设置完成。请重启 '+@{codex='Codex';workbuddy='WorkBuddy'}[$Product]+'；对话和图片组件均已配置，无需额外下载运行时。')
} catch {
    $exitCode=1; $report.status='failed'; $report.code=Error-Code $_
    $details=Explain-Error $report.code
    Write-Host ("失败步骤：{0} [{1}]`n原因：{2}`n下一步：{3}" -f $report.stage,$report.code,$details[0],$details[1])
} finally {
    $key=$null
    if ($setupLock) { $setupLock.Dispose() }
    if ($work -and [IO.Directory]::Exists($work)) {
        try { Assert-LocalPath $work; if ([IO.Path]::GetDirectoryName($work) -eq (Join-Path $directory 'realyu-runtime')) { Remove-Item -LiteralPath $work -Recurse -Force } } catch { }
    }
    try { $diagnostics=Join-Path $directory 'realyu-diagnostics';New-PrivateDirectory $diagnostics;Write-Atomic (Join-Path $diagnostics ($report.id+'.json')) ($utf8.GetBytes((To-Json $report))) } catch { }
    if ($report.code) {
        $details=Explain-Error $report.code
        if ($report.status -ne 'failed') { Write-Host ($details[0]+' 下一步：'+$details[1]) }
        Write-Host ('诊断编号：'+$report.id)
        Write-Host (To-Json $report)
        if ($env:REALYU_DIAGNOSTICS_UPLOAD -ne '0') {
            try {
                $payload=@{};foreach ($name in @('id','client_version','platform','architecture','stage','code','http_status','elevation','codex_version')) { if ($report.ContainsKey($name)) { $payload[$name]=$report[$name] } }
                $request=[Net.HttpWebRequest]::Create($diagnosticsUrl);$request.AllowAutoRedirect=$false;$request.Method='POST';$request.ContentType='application/json';$request.Timeout=5000;$request.ReadWriteTimeout=5000
                $bytes=$utf8.GetBytes((To-Json $payload));$request.ContentLength=$bytes.Length;$stream=$request.GetRequestStream();$stream.Write($bytes,0,$bytes.Length);$stream.Dispose();$response=$request.GetResponse();$response.Dispose()
            } catch { }
        }
    }
}
exit $exitCode
