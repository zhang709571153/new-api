// Fixed-endpoint streaming image transport using Windows inbox .NET only.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
namespace RealyuNative {
    public class ImageReply {public string Encoded; public string RequestId;}
    public class ImageFiles {public int Width;public int Height;public byte[] Preview;}
    public sealed class LimitedStream : Stream {
        Stream input;long received;long limit;
        public LimitedStream(Stream source,long maximum) {input=source;limit=maximum;}
        public override int Read(byte[] buffer,int offset,int count) {
            int read=input.Read(buffer,offset,(int)Math.Min(count,limit-received+1)); received+=read;
            Images.ReceivedBytes=received;
            if(received>limit)throw new Exception("IMAGE_RESPONSE_TOO_LARGE");return read;
        }
        public override bool CanRead {get{return true;}} public override bool CanWrite {get{return false;}} public override bool CanSeek {get{return false;}}
        public override long Length {get{throw new NotSupportedException();}} public override long Position {get{return received;}set{throw new NotSupportedException();}}
        public override void Flush(){} public override long Seek(long offset,SeekOrigin origin){throw new NotSupportedException();}
        public override void SetLength(long value){throw new NotSupportedException();}public override void Write(byte[] b,int o,int c){throw new NotSupportedException();}
        protected override void Dispose(bool disposing){if(disposing)input.Dispose();base.Dispose(disposing);}
    }
    public static class Images {
        [ThreadStatic] public static string RequestId;
        [ThreadStatic] public static string TransportStage;
        [ThreadStatic] public static string LastEvent;
        [ThreadStatic] public static string UpstreamErrorCode;
        [ThreadStatic] public static long ReceivedBytes;
        [ThreadStatic] public static int HttpStatus;
        static string SafeLabel(object value,bool eventType) {
            string label=value as string;if(string.IsNullOrEmpty(label))return null;
            // Never echo arbitrary upstream labels: even an error code can contain a secret.
            string[] allowed=eventType
                ? new[]{"error","response.created","response.queued","response.in_progress","response.output_item.added","response.output_item.done","response.content_part.added","response.content_part.done","response.output_text.delta","response.output_text.done","response.image_generation_call.in_progress","response.image_generation_call.generating","response.image_generation_call.partial_image","response.image_generation_call.completed","response.completed","response.failed","response.incomplete","response.cancelled"}
                : new[]{"server_error","internal_error","upstream_error","rate_limit_exceeded","insufficient_quota","image_generation_failed","image_generation_error","image_generation_user_error","invalid_request_error","content_policy_violation","moderation_blocked","invalid_api_key","model_not_found","unsupported_model","overloaded","timeout","context_length_exceeded"};
            foreach(string known in allowed)if(label==known)return label;
            return "other";
        }
        static JavaScriptSerializer Json(){return new JavaScriptSerializer{MaxJsonLength=50331648,RecursionLimit=100};}
        static HttpWebRequest Request(string url,string key,int timeout) {
            ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;
            var request=(HttpWebRequest)WebRequest.Create(url);
            // Keep the Windows user/system proxy selected by HttpWebRequest.
            request.AllowAutoRedirect=false;request.Timeout=timeout;request.ReadWriteTimeout=timeout;
            request.UserAgent="Realyu-Codex-Images/1.4.32";request.Headers["Accept-Encoding"]="identity";
            if(key!=null)request.Headers["Authorization"]="Bearer "+key;
            return request;
        }
        static HttpWebResponse Response(HttpWebRequest request) {
            HttpWebResponse response;
            try{response=(HttpWebResponse)request.GetResponse();}
            catch(WebException error) {
                if(error.Response!=null){RequestId=error.Response.Headers["X-Oneapi-Request-Id"];int status=(int)((HttpWebResponse)error.Response).StatusCode;HttpStatus=status;error.Response.Dispose();throw new Exception("IMAGE_HTTP_"+status);}
                if(error.Status==WebExceptionStatus.Timeout || error.Status==WebExceptionStatus.RequestCanceled)throw new Exception("IMAGE_TIMEOUT");
                if(error.Status==WebExceptionStatus.TrustFailure || error.Status==WebExceptionStatus.SecureChannelFailure)throw new Exception("IMAGE_TLS_ERROR");
                throw new Exception("IMAGE_NETWORK_ERROR");
            }
            int code=(int)response.StatusCode;HttpStatus=code;
            RequestId=response.Headers["X-Oneapi-Request-Id"];
            if(code!=200){response.Dispose();throw new Exception("IMAGE_HTTP_"+code);}
            if(!string.IsNullOrEmpty(response.ContentEncoding) && response.ContentEncoding!="identity") {response.Dispose();throw new Exception("IMAGE_ENCODING_INVALID");}
            return response;
        }
        public static string Check(string url,string key) {
            var request=Request(url,key,15000);
            using(var response=Response(request))
            using(var limited=new LimitedStream(response.GetResponseStream(),1048576))
            using(var reader=new StreamReader(limited,new UTF8Encoding(false,true))) return reader.ReadToEnd();
        }
        public static ImageReply Generate(string url,string key,string body) {
            RequestId=null;TransportStage="prepare";LastEvent=null;UpstreamErrorCode=null;ReceivedBytes=0;HttpStatus=0;
            try {return GenerateCore(url,key,body);}
            catch(WebException error) {
                if(error.Status==WebExceptionStatus.Timeout || error.Status==WebExceptionStatus.RequestCanceled)throw new Exception("IMAGE_TIMEOUT");
                if(error.Status==WebExceptionStatus.TrustFailure || error.Status==WebExceptionStatus.SecureChannelFailure)throw new Exception("IMAGE_TLS_ERROR");
                throw new Exception("IMAGE_NETWORK_ERROR");
            }
            catch(IOException) {throw new Exception("IMAGE_RESPONSE_INCOMPLETE");}
            catch(ArgumentException) {throw new Exception("IMAGE_RESPONSE_INVALID");}
            catch(InvalidOperationException) {throw new Exception("IMAGE_RESPONSE_INVALID");}
            catch(KeyNotFoundException) {throw new Exception("IMAGE_RESPONSE_INVALID");}
        }
        static ImageReply GenerateCore(string url,string key,string body) {
            var request=Request(url,key,300000);request.Method="POST";request.ContentType="application/json";request.Accept="text/event-stream";
            byte[] bytes=Encoding.UTF8.GetBytes(body);request.ContentLength=bytes.Length;
            // One attempt only: a disconnect after acceptance must not double-charge.
            using(var deadline=new Timer(delegate(object ignored){request.Abort();},null,300000,Timeout.Infinite)) {
                TransportStage="request_write";
                using(var stream=request.GetRequestStream()) stream.Write(bytes,0,bytes.Length);
                TransportStage="response_headers";
                using(var response=Response(request)) {
                    if(response.ContentLength>50331648)throw new Exception("IMAGE_RESPONSE_TOO_LARGE");
                    if(!response.ContentType.StartsWith("text/event-stream",StringComparison.OrdinalIgnoreCase))throw new Exception("IMAGE_RESPONSE_INVALID");
                    TransportStage="response_stream";
                    string encoded=null;var data=new StringBuilder();bool complete=false;
                    using(var limited=new LimitedStream(response.GetResponseStream(),50331648))
                    using(var reader=new StreamReader(limited,new UTF8Encoding(false,true))) {
                        string line;
                        while((line=reader.ReadLine())!=null) {
                            if(line.Length!=0) {if(line.StartsWith("data:")){string part=line.Substring(5);if(part.StartsWith(" "))part=part.Substring(1);data.Append(part).Append('\n');}continue;}
                            if(data.Length==0)continue;
                            string raw=data.ToString().TrimEnd('\n');data.Length=0;
                            if(raw=="[DONE]")break;
                            var value=Json().Deserialize<Dictionary<string,object>>(raw);
                            string kind=Convert.ToString(value["type"]);
                            LastEvent=SafeLabel(kind,true);
                            if(kind=="error" || kind=="response.failed" || kind=="response.incomplete" || kind=="response.cancelled") {
                                object errorValue;Dictionary<string,object> failure=null;
                                if(value.TryGetValue("error",out errorValue))failure=errorValue as Dictionary<string,object>;
                                object responseValue;
                                if(failure==null && value.TryGetValue("response",out responseValue)) {
                                    var failedResponse=responseValue as Dictionary<string,object>;
                                    if(failedResponse!=null && failedResponse.TryGetValue("error",out errorValue))failure=errorValue as Dictionary<string,object>;
                                }
                                if(failure!=null && failure.TryGetValue("code",out errorValue))UpstreamErrorCode=SafeLabel(errorValue,false);
                                if(UpstreamErrorCode==null && value.TryGetValue("code",out errorValue))UpstreamErrorCode=SafeLabel(errorValue,false);
                                throw new Exception("IMAGE_GENERATION_FAILED");
                            }
                            if(kind=="response.output_item.done") {
                                var item=value["item"] as Dictionary<string,object>;
                                if(item!=null && Convert.ToString(item["type"])=="image_generation_call" && item.ContainsKey("result"))encoded=item["result"] as string;
                            }
                            if(kind=="response.completed") {
                                var result=value["response"] as Dictionary<string,object>;
                                if(result==null || Convert.ToString(result["status"])!="completed")throw new Exception("IMAGE_GENERATION_FAILED");
                                if(result.ContainsKey("output")) {
                                    var items=result["output"] as System.Collections.IEnumerable;
                                    if(items!=null)foreach(var element in items){var item=element as Dictionary<string,object>;if(item!=null && Convert.ToString(item["type"])=="image_generation_call" && item.ContainsKey("result"))encoded=item["result"] as string;}
                                }
                                complete=true;break;
                            }
                        }
                    }
                    if(!complete || string.IsNullOrEmpty(encoded))throw new Exception("IMAGE_RESPONSE_INCOMPLETE");
                    TransportStage="response_complete";
                    return new ImageReply{Encoded=encoded,RequestId=response.Headers["X-Oneapi-Request-Id"]};
                }
            }
        }
        public static string Mime(byte[] bytes) {
            if(bytes.Length>=24 && bytes[0]==137 && Encoding.ASCII.GetString(bytes,1,3)=="PNG" && bytes[4]==13 && bytes[5]==10 && bytes[6]==26 && bytes[7]==10)return "image/png";
            if(bytes.Length>=4 && bytes[0]==255 && bytes[1]==216 && bytes[2]==255)return "image/jpeg";
            if(bytes.Length>=30 && Encoding.ASCII.GetString(bytes,0,4)=="RIFF" && Encoding.ASCII.GetString(bytes,8,4)=="WEBP")return "image/webp";
            throw new Exception("IMAGE_FORMAT_INVALID");
        }
        public static void ValidateInput(byte[] bytes) {
            if(bytes.Length>20971520)throw new Exception("IMAGE_INPUT_TOO_LARGE");
            if(Mime(bytes)=="image/webp") {
                // Windows' PNG/JPEG decoder does not require the optional WebP codec.
                // Validate the WebP container and dimensions; the gateway decodes pixels.
                if((long)BitConverter.ToUInt32(bytes,4)+8!=bytes.Length)throw new Exception("IMAGE_FORMAT_INVALID");
                string chunk=Encoding.ASCII.GetString(bytes,12,4);long width,height;
                if(chunk=="VP8X") {width=1+bytes[24]+(bytes[25]<<8)+(bytes[26]<<16);height=1+bytes[27]+(bytes[28]<<8)+(bytes[29]<<16);}
                else if(chunk=="VP8L" && bytes[20]==47){uint bits=BitConverter.ToUInt32(bytes,21);width=1+(bits&16383);height=1+((bits>>14)&16383);}
                else if(chunk=="VP8 " && bytes[23]==157 && bytes[24]==1 && bytes[25]==42){width=BitConverter.ToUInt16(bytes,26)&16383;height=BitConverter.ToUInt16(bytes,28)&16383;}
                else throw new Exception("IMAGE_FORMAT_INVALID");
                if(width<=0 || height<=0 || width*height>40000000)throw new Exception("IMAGE_DIMENSIONS_INVALID");return;
            }
            using(var stream=new MemoryStream(bytes))using(var image=Image.FromStream(stream,false,true)){
                if((long)image.Width*image.Height>40000000)throw new Exception("IMAGE_DIMENSIONS_INVALID");
            }
        }
        public static ImageFiles Preview(byte[] bytes) {
            if(Mime(bytes)!="image/png")throw new Exception("IMAGE_FORMAT_INVALID");
            ValidateInput(bytes);
            using(var stream=new MemoryStream(bytes))using(var image=Image.FromStream(stream,false,true)) {
                double scale=Math.Min(1.0,512.0/Math.Max(image.Width,image.Height));
                int width=Math.Max(1,(int)Math.Round(image.Width*scale)),height=Math.Max(1,(int)Math.Round(image.Height*scale));
                using(var bitmap=new Bitmap(width,height,PixelFormat.Format32bppArgb)) {
                    using(var graphics=Graphics.FromImage(bitmap)) {graphics.CompositingMode=CompositingMode.SourceCopy;graphics.InterpolationMode=InterpolationMode.HighQualityBicubic;graphics.PixelOffsetMode=PixelOffsetMode.HighQuality;graphics.DrawImage(image,0,0,width,height);}
                    using(var output=new MemoryStream()) {bitmap.Save(output,ImageFormat.Png);if(output.Length>2097152)throw new Exception("IMAGE_PREVIEW_TOO_LARGE");return new ImageFiles{Width=image.Width,Height=image.Height,Preview=output.ToArray()};}
                }
            }
        }
    }
}
