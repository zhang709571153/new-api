// Windows inbox .NET + winsqlite3 only. No downloaded runtime or managed DLL.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;

namespace RealyuNative {
    public class Result { public int Code; public string Output; public string Error; }
    public static class ProcessHost {
        public static string Quote(string value) {
            var b = new StringBuilder("\""); int slashes = 0;
            foreach(char c in value) {
                if(c == '\\') { slashes++; continue; }
                if(c == '"') { b.Append('\\', slashes * 2 + 1); b.Append(c); slashes = 0; continue; }
                b.Append('\\', slashes); slashes = 0; b.Append(c);
            }
            b.Append('\\', slashes * 2); return b.Append('"').ToString();
        }
        public static Process Start(string exe, string[] args, string home) {
            var start = new ProcessStartInfo(exe);
            var parts = new List<string>(); foreach(var arg in args) parts.Add(Quote(arg));
            start.Arguments = string.Join(" ", parts.ToArray());
            start.UseShellExecute=false; start.CreateNoWindow=true;
            start.RedirectStandardInput=true; start.RedirectStandardOutput=true; start.RedirectStandardError=true;
            start.StandardOutputEncoding=new UTF8Encoding(false); start.StandardErrorEncoding=new UTF8Encoding(false);
            start.WorkingDirectory=home; start.EnvironmentVariables["CODEX_HOME"]=home;
            var keys = new List<string>(); foreach(string key in start.EnvironmentVariables.Keys) keys.Add(key);
            foreach(var key in keys) if(key.ToUpperInvariant().Contains("PROXY") || key == "OPENAI_API_KEY" || key == "OPENAI_BASE_URL" || key == "REALYU_API_KEY") start.EnvironmentVariables.Remove(key);
            return Process.Start(start);
        }
        public static Result Run(string exe,string[] args,string home,string input,int timeout) {
            using(var process=Start(exe,args,home)) {
                var stdout=process.StandardOutput.ReadToEndAsync(); var stderr=process.StandardError.ReadToEndAsync();
                if(input!=null) process.StandardInput.Write(input);
                process.StandardInput.Close();
                if(!process.WaitForExit(timeout)) { process.Kill(); process.WaitForExit(); throw new Exception("CODEX_TIMEOUT"); }
                return new Result { Code=process.ExitCode, Output=stdout.Result, Error=stderr.Result };
            }
        }
    }
    public sealed class Rpc : IDisposable {
        Process process; int sequence; JavaScriptSerializer json=new JavaScriptSerializer {MaxJsonLength=67108864, RecursionLimit=200};
        public Rpc(string exe,string home,string[] args) { process=ProcessHost.Start(exe,args,home); process.StandardError.ReadToEndAsync(); }
        public void Send(string value) { process.StandardInput.WriteLine(value); process.StandardInput.Flush(); }
        public string Call(string method,string parameters,int timeout) {
            int id=++sequence;
            Send("{\"jsonrpc\":\"2.0\",\"id\":"+id+",\"method\":"+json.Serialize(method)+",\"params\":"+parameters+"}");
            var clock=Stopwatch.StartNew();
            while(true) {
                var pending=process.StandardOutput.ReadLineAsync();
                int remaining=timeout-(int)clock.ElapsedMilliseconds;
                if(remaining<=0 || !pending.Wait(remaining)) throw new Exception("SESSIONS_TIMEOUT");
                if(pending.Result==null) throw new Exception("SESSIONS_RPC_FAILED");
                var value=json.Deserialize<Dictionary<string,object>>(pending.Result);
                if(value.ContainsKey("method") && value.ContainsKey("id")) {
                    Send("{\"jsonrpc\":\"2.0\",\"id\":"+json.Serialize(value["id"])+",\"error\":{\"code\":-32601,\"message\":\"Unavailable during setup\"}}"); continue;
                }
                if(!value.ContainsKey("id") || !object.Equals(value["id"],id)) continue;
                if(value.ContainsKey("error")) {
                    var error=(Dictionary<string,object>)value["error"];
                    string message=Convert.ToString(error["message"]);
                    if(message.Contains("active writer")) throw new Exception("SESSIONS_BUSY");
                    if(Convert.ToInt32(error["code"])==-32601 || message.Contains("experimentalApi")) throw new Exception("SESSIONS_CLIENT_UNSUPPORTED");
                    throw new Exception("SESSIONS_RPC_FAILED");
                }
                return json.Serialize(value["result"]);
            }
        }
        public void Dispose() {
            if(process==null) return;
            try { process.StandardInput.Close(); if(!process.WaitForExit(5000)) {process.Kill();process.WaitForExit(5000);} }
            finally { process.Dispose(); process=null; }
        }
    }
    public static class Files {
        public static void Atomic(string path,byte[] bytes) {
            string temp=Path.Combine(Path.GetDirectoryName(path),".realyu-"+Guid.NewGuid().ToString("N"));
            try {
                using(var file=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {file.Write(bytes,0,bytes.Length);file.Flush(true);}
                if(File.Exists(path)) File.Replace(temp,path,null); else File.Move(temp,path);
            } finally {if(File.Exists(temp)) File.Delete(temp);}
        }
        public static void Idle(string folder) {
            if(!Directory.Exists(folder)) return;
            foreach(string file in Directory.GetFiles(folder,"*.lock")) {
                if((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0) throw new Exception("SESSIONS_PATH_UNSAFE");
                try {using(var stream=new FileStream(file,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite)) {stream.Lock(0,1);stream.Unlock(0,1);}}
                catch(FileNotFoundException) {} catch(IOException) {throw new Exception("SESSIONS_BUSY");}
            }
        }
    }
    public class ThreadIndex { public string Id; public bool Archived; }
    public static class Sqlite {
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_open_v2(byte[] path,out IntPtr db,int flags,IntPtr vfs);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_close(IntPtr db);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_busy_timeout(IntPtr db,int milliseconds);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_prepare_v2(IntPtr db,byte[] sql,int n,out IntPtr stmt,IntPtr tail);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_step(IntPtr stmt);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern IntPtr sqlite3_column_text(IntPtr stmt,int column);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_column_bytes(IntPtr stmt,int column);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_column_int(IntPtr stmt,int column);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_finalize(IntPtr stmt);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern IntPtr sqlite3_backup_init(IntPtr target,byte[] targetName,IntPtr source,byte[] sourceName);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_backup_step(IntPtr backup,int pages);
        [DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)] static extern int sqlite3_backup_finish(IntPtr backup);
        static byte[] Utf8(string text) {return Encoding.UTF8.GetBytes(text+"\0");}
        static IntPtr Open(string path,int flags) {IntPtr db; if(sqlite3_open_v2(Utf8(path),out db,flags,IntPtr.Zero)!=0) {if(db!=IntPtr.Zero)sqlite3_close(db);throw new Exception("SESSIONS_INDEX_UNSUPPORTED");}sqlite3_busy_timeout(db,3000);return db;}
        public static ThreadIndex[] Read(string path) {
            IntPtr db=Open(path,1), stmt=IntPtr.Zero;
            try {
                if(sqlite3_prepare_v2(db,Utf8("SELECT id, archived FROM threads"),-1,out stmt,IntPtr.Zero)!=0) throw new Exception("SESSIONS_INDEX_UNSUPPORTED");
                var rows=new List<ThreadIndex>(); int result;
                while((result=sqlite3_step(stmt))==100) {
                    int length=sqlite3_column_bytes(stmt,0);var bytes=new byte[length];Marshal.Copy(sqlite3_column_text(stmt,0),bytes,0,length);
                    rows.Add(new ThreadIndex {Id=Encoding.UTF8.GetString(bytes),Archived=sqlite3_column_int(stmt,1)!=0});
                }
                if(result!=101) throw new Exception("SESSIONS_INDEX_UNSUPPORTED");
                return rows.ToArray();
            } finally {if(stmt!=IntPtr.Zero)sqlite3_finalize(stmt);sqlite3_close(db);}
        }
        public static void Backup(string source,string target) {
            IntPtr from=Open(source,1),to=IntPtr.Zero,backup=IntPtr.Zero;
            try {
                to=Open(target,6);backup=sqlite3_backup_init(to,Utf8("main"),from,Utf8("main"));
                if(backup==IntPtr.Zero || sqlite3_backup_step(backup,-1)!=101) throw new Exception("SESSIONS_BACKUP_FAILED");
            } finally {if(backup!=IntPtr.Zero)sqlite3_backup_finish(backup);if(to!=IntPtr.Zero)sqlite3_close(to);sqlite3_close(from);}
        }
    }
}
