﻿function Install-WorkBuddyConnection([string]$Directory,[string]$Key,[string]$Backup) {
    . (Join-Path $PSScriptRoot 'workbuddy-config.ps1')
    $mcpPath=Join-Path $Directory 'mcp.json'; $modelsPath=Join-Path $Directory 'models.json'
    Assert-LocalPath $mcpPath;Assert-LocalPath $modelsPath
    $mcpBytes=if ([IO.File]::Exists($mcpPath)) { [IO.File]::ReadAllBytes($mcpPath) } else { $null }
    $modelBytes=if ([IO.File]::Exists($modelsPath)) { [IO.File]::ReadAllBytes($modelsPath) } else { $null }
    $mcp=@{mcpServers=@{}}
    if ($mcpBytes) { Test-RealyuConfigJson ($utf8.GetString($mcpBytes).TrimStart([char]65279));$mcp=Parse-Json ($utf8.GetString($mcpBytes).TrimStart([char]65279)) }
    if ($mcp['mcpServers'] -isnot [Collections.IDictionary]) { throw 'CONFIG_JSON_INVALID' }
    $old=$mcp['mcpServers']['image_generation']
    if ($old -and ($old['url'] -or $old['env']['REALYU_WORKBUDDY_HOME'] -ne $Directory -or @($old['args'])[-1] -notlike ($Directory+'\realyu-runtime\scripts\*\realyu-images.ps1'))) { throw 'CONFIG_IMAGE_TOOL_CONFLICT' }
    $names=@('common.ps1','native.cs','image.cs','realyu-images.ps1','tools.json','errors.json')
    $identity=($names | ForEach-Object { Get-Sha (Join-Path $PSScriptRoot $_) }) -join ''
    $sha=[Security.Cryptography.SHA256]::Create()
    try { $digest=[BitConverter]::ToString($sha.ComputeHash($utf8.GetBytes($identity))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
    $runtime=Join-Path $Directory "realyu-runtime\scripts\$digest";New-PrivateDirectory $runtime
    foreach ($name in $names) {
        $target=Join-Path $runtime $name;Assert-LocalPath $target
        if ([IO.File]::Exists($target)) { if ((Get-Sha $target) -ne (Get-Sha (Join-Path $PSScriptRoot $name))) { throw 'HELPER_CACHE_INVALID' } }
        else { Write-Atomic $target ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $name))) }
    }
    $mcp['mcpServers']['image_generation']=@{command=(Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe');args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $runtime 'realyu-images.ps1'));env=@{REALYU_WORKBUDDY_HOME=$Directory;REALYU_CODEX_HOME=$Directory}}
    if ($mcpBytes) { [IO.File]::WriteAllBytes((Join-Path $Backup 'mcp.json'),$mcpBytes) }
    if ($modelBytes) { [IO.File]::WriteAllBytes((Join-Path $Backup 'models.json'),$modelBytes) }
    $stage=Join-Path $Backup 'workbuddy-stage';New-PrivateDirectory $stage
    if ($modelBytes) { [IO.File]::WriteAllBytes((Join-Path $stage 'models.json'),$modelBytes) }
    $result=Install-RealyuWorkBuddy -Key $Key -ConfigDirectory $stage
    $document=Parse-Json ([IO.File]::ReadAllText((Join-Path $stage 'models.json'),$utf8))
    $models=if ($document -is [Array]) { $document } else { $document['models'] }
    foreach ($model in $models) { if ($model['url'] -ceq 'https://api.realyu.fun/v1/chat/completions') { $model['apiKey']=$Key } }
    $targets=@{'models.json'=$utf8.GetBytes((To-Json $document));'mcp.json'=$utf8.GetBytes((To-Json $mcp))}
    $before=@{'models.json'=$modelBytes;'mcp.json'=$mcpBytes}
    foreach ($name in $before.Keys) {
        $path=Join-Path $Directory $name
        $current=if ([IO.File]::Exists($path)) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($path)) } else { $null }
        $expected=if ($null -ne $before[$name]) { [Convert]::ToBase64String($before[$name]) } else { $null }
        if ($current -cne $expected) { throw 'CONFIG_CHANGED' }
    }
    $changed=[Collections.Generic.List[string]]::new()
    try {
        foreach ($name in @('models.json','mcp.json')) { Write-Atomic (Join-Path $Directory $name) $targets[$name];$changed.Add($name) }
    } catch {
        $failed=$false
        foreach ($name in $changed) {
            try {
                $path=Join-Path $Directory $name
                if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($path)) -cne [Convert]::ToBase64String($targets[$name])) { $failed=$true;continue }
                if ($null -eq $before[$name]) { [IO.File]::Delete($path) } else { Write-Atomic $path $before[$name] }
            } catch { $failed=$true }
        }
        if ($failed) { throw 'CONFIG_RESTORE_FAILED' }
        throw 'CONFIG_WRITE_FAILED'
    }
    Write-Host ('已导入 '+$result.Models.Count+' 个模型并配置图片工具。')
}
