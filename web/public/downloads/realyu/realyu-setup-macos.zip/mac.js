/* macOS inbox JavaScript for Automation/Foundation, curl, sqlite3 and sips.
 * No Python, Node, SDK installation or first-use component download.
 */
ObjC.import('Foundation');
ObjC.bindFunction('rename',['int',['char *','char *']]);
// JXA accepts canonical C type names; the C# alias ushort aborts the ObjC bridge.
ObjC.bindFunction('chmod',['int',['char *','unsigned short']]);
ObjC.bindFunction('kill',['int',['int','int']]);
var fm=$.NSFileManager.defaultManager;
var env=ObjC.deepUnwrap($.NSProcessInfo.processInfo.environment);
var BASE='https://api.realyu.fun/v1', KEY_URL='https://api.realyu.fun/api/client/key-check', STATUS_URL='https://api.realyu.fun/api/status';
var VERSION='1.4.30', ROOT='', HOME='', KIND='', WORK='', CLI='', CLI_VERSION='unknown', REPORT=null;
var stdinBuffer=$.NSMutableData.data, input=$.NSFileHandle.fileHandleWithStandardInput, output=$.NSFileHandle.fileHandleWithStandardOutput;
function uuid(){return ObjC.unwrap($.NSUUID.UUID.UUIDString).toLowerCase().replace(/-/g,'');}
function fail(code){throw new Error(code);}
function nil(value){return value===null||value===undefined||(typeof value.isNil==='function'&&value.isNil());}
function utf8(text){return $(text).dataUsingEncoding($.NSUTF8StringEncoding);}
function decode(data){var value=$.NSString.alloc.initWithDataEncoding(data,$.NSUTF8StringEncoding);if(nil(value))fail('FILE_ENCODING_INVALID');return ObjC.unwrap(value);}
function print(text){output.writeData(utf8(text+'\n'));}
function join(a,b){return a.replace(/\/$/,'')+'/'+b;}
function exists(path){return Boolean(fm.fileExistsAtPath($(path)));}
function normal(path){return ObjC.unwrap($(path).stringByStandardizingPath);}
function safe(path){
    path=normal(path);if(path[0]!=='/')fail('PATH_UNSAFE');
    var current=path;
    while(current!=='/'){
        var attributes=fm.attributesOfItemAtPathError($(current),null);
        if(!nil(attributes) && ObjC.unwrap(attributes.objectForKey($.NSFileType))==='NSFileTypeSymbolicLink')fail('PATH_UNSAFE');
        current=current.slice(0,current.lastIndexOf('/'))||'/';
    }
    return path;
}
function mkdir(path){safe(path);if(!fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(path),true,$({NSFilePosixPermissions:448}),null))fail('FILESYSTEM_ACCESS_DENIED');}
function readBytes(path,limit){safe(path);var data=$.NSData.dataWithContentsOfFile($(path));if(nil(data))fail('FILE_NOT_FOUND');if(Number(data.length)>(limit||67108864))fail('FILE_TOO_LARGE');return data;}
function read(path,limit){return decode(readBytes(path,limit));}
function atomicBytes(path,data){
    safe(path);var temp=join(path.slice(0,path.lastIndexOf('/')),'.realyu-'+uuid());
    if(!data.writeToFileAtomically($(temp),false))fail('FILESYSTEM_ACCESS_DENIED');
    if($.chmod(temp,384)!==0){fm.removeItemAtPathError($(temp),null);fail('FILESYSTEM_ACCESS_DENIED');}
    if($.rename(temp,path)!==0){fm.removeItemAtPathError($(temp),null);fail('FILESYSTEM_ERROR');}
}
function write(path,text){atomicBytes(path,utf8(text));}
function remove(path){safe(path);if(exists(path)&&!fm.removeItemAtPathError($(path),null))fail('FILESYSTEM_ERROR');}
function copy(source,target){atomicBytes(target,readBytes(source));}
function list(path){if(!exists(path))return [];return ObjC.deepUnwrap(fm.contentsOfDirectoryAtPathError($(path),null))||[];}
function sleep(ms){$.NSThread.sleepForTimeInterval(ms/1000);}
function bufferedLine(buffer){
    var length=Number(buffer.length);if(!length)return null;
    var range=buffer.rangeOfDataOptionsRange(utf8('\n'),0,$.NSMakeRange(0,length)),offset=Number(range.location);
    if(offset>=length)return null;
    var line=decode(buffer.subdataWithRange($.NSMakeRange(0,offset)));
    var rest=buffer.subdataWithRange($.NSMakeRange(offset+1,length-offset-1));buffer.setData(rest);return line.replace(/\r$/,'');
}
function readLine(){
    for(;;){var line=bufferedLine(stdinBuffer);if(line!==null)return line;
        var data=input.availableData;if(Number(data.length)===0){if(!Number(stdinBuffer.length))return null;var last=decode(stdinBuffer);stdinBuffer.setLength(0);return last;}
        stdinBuffer.appendData(data);if(Number(stdinBuffer.length)>1048576)fail('MCP_REQUEST_TOO_LARGE');}
}
function proxyEnvironment(){var result={};['https_proxy','HTTPS_PROXY','all_proxy','ALL_PROXY','http_proxy','no_proxy','NO_PROXY'].forEach(function(name){if(typeof env[name]==='string')result[name]=env[name];});return result;}
function childEnvironment(home,withProxy){var clean={};Object.keys(env).forEach(function(k){if(k.toUpperCase().indexOf('PROXY')<0&&['OPENAI_API_KEY','OPENAI_BASE_URL','REALYU_API_KEY'].indexOf(k)<0)clean[k]=env[k];});clean.CODEX_HOME=home||HOME;if(withProxy)Object.assign(clean,proxyEnvironment());return clean;}
function fileURI(path){if(typeof path!=='string'||path[0]!=='/')fail('IMAGE_PATH_INVALID');return 'file://'+path.split('/').map(function(part){return encodeURIComponent(part);}).join('/');}
function Process(exe,args,home){
    this.dir=join(WORK,'process-'+uuid());mkdir(this.dir);this.out=join(this.dir,'stdout');write(this.out,'');
    this.task=$.NSTask.alloc.init;this.task.launchPath=$(exe);this.task.arguments=$(args);this.task.currentDirectoryPath=$(home||HOME);
    this.task.environment=$(childEnvironment(home,exe==='/usr/bin/curl'));
    this.pipe=$.NSPipe.pipe;this.task.standardInput=this.pipe;
    this.writer=$.NSFileHandle.fileHandleForWritingAtPath($(this.out));this.task.standardOutput=this.writer;
    this.errorPath=exe==='/usr/bin/curl'?join(this.dir,'transport'):null;
    if(this.errorPath)write(this.errorPath,'');
    this.errorWriter=$.NSFileHandle.fileHandleForWritingAtPath($(this.errorPath||'/dev/null'));this.task.standardError=this.errorWriter;
    try{this.task.launch;}catch(error){fail('PROCESS_START_FAILED');}
    this.reader=$.NSFileHandle.fileHandleForReadingAtPath($(this.out));this.buffer=$.NSMutableData.data;this.closed=false;this.received=0;
}
Process.prototype.send=function(text){try{this.pipe.fileHandleForWriting.writeData(utf8(text));}catch(e){fail('SESSIONS_RPC_FAILED');}};
Process.prototype.endInput=function(){if(!this.closed){this.pipe.fileHandleForWriting.closeFile;this.closed=true;}};
Process.prototype.line=function(deadline){
    while(Date.now()<deadline){var line=bufferedLine(this.buffer);if(line!==null)return line;
        var data=this.reader.readDataToEndOfFile;if(Number(data.length)){this.received+=Number(data.length);if(this.received>67108864)fail('RESPONSE_TOO_LARGE');this.buffer.appendData(data);continue;}
        if(!this.task.running){if(Number(this.buffer.length)){var last=decode(this.buffer);this.buffer.setLength(0);return last;}fail('SESSIONS_RPC_FAILED');}sleep(20);
    }fail('SESSIONS_TIMEOUT');
};
Process.prototype.close=function(){
    try{this.endInput();var deadline=Date.now()+1500;while(this.task.running&&Date.now()<deadline)sleep(20);if(this.task.running){this.task.terminate;sleep(100);if(this.task.running)$.kill(Number(this.task.processIdentifier),9);}}
    finally{this.reader.closeFile;this.writer.closeFile;this.errorWriter.closeFile;remove(this.dir);}
};
function runProcess(exe,args,home,text,timeout){
    var p=new Process(exe,args,home);try{if(text!==undefined&&text!==null)p.send(text);p.endInput();var deadline=Date.now()+(timeout||30000);
        while(p.task.running){if(Date.now()>deadline)fail('PROCESS_TIMEOUT');sleep(20);}
        return {code:Number(p.task.terminationStatus),text:read(p.out)};
    }finally{p.close();}
}
function Rpc(exe,home){this.sequence=0;
    try{this.process=new Process(exe,['-c','features.shell_snapshot=false','app-server'],home);}
    catch(e){if(REPORT&&REPORT.stage==='configuration'&&code(e)==='PROCESS_START_FAILED')fail('CONFIG_PROCESS_START_FAILED');throw e;}
    try{this.call('initialize',{clientInfo:{name:'realyu_setup',version:VERSION},capabilities:{experimentalApi:true}});this.process.send('{"method":"initialized","params":{}}\n');}
    catch(e){this.close();if(REPORT&&REPORT.stage==='configuration'&&code(e)==='SESSIONS_RPC_FAILED')fail('CONFIG_RPC_FAILED');throw e;}}
Rpc.prototype.call=function(method,params){
    var configuration=REPORT&&REPORT.stage==='configuration';
    if(configuration&&['initialize','config/read','config/batchWrite','configRequirements/read'].indexOf(method)>=0)REPORT.rpc_method=method;
    try{
        var id=++this.sequence;this.process.send(JSON.stringify({id:id,method:method,params:params})+'\n');var deadline=Date.now()+60000;
        for(;;){var line=this.process.line(deadline),value;
            try{value=JSON.parse(line);}catch(e){if(configuration)fail('CONFIG_RPC_FAILED');throw e;}
            if(!value||typeof value!=='object'||Array.isArray(value)){if(configuration)fail('CONFIG_RPC_FAILED');fail('SESSIONS_RPC_FAILED');}
            if(value.method&&value.id!==undefined){this.process.send(JSON.stringify({id:value.id,error:{code:-32601,message:'Unavailable during setup'}})+'\n');continue;}
            if(value.id!==id)continue;
            if(value.error){
                var message=String(value.error.message||'');
                if(configuration&&['initialize','config/read','config/batchWrite','configRequirements/read'].indexOf(method)>=0){
                    REPORT.rpc_method=method;REPORT.rpc_error_code=Number.isInteger(value.error.code)?value.error.code:0;
                    print('[配置接口] '+method+' 返回错误 '+REPORT.rpc_error_code+'；阶段='+String(REPORT.config_step||'unknown')+'；Codex='+CLI_VERSION);
                    if(/model_catalog_json/i.test(message)){REPORT.config_field='model_catalog_json';fail('CONFIG_MODEL_CATALOG_INCOMPATIBLE');}
                }
                if(/active writer/i.test(message))fail('SESSIONS_BUSY');
                if(value.error.code===-32601||/experimentalApi/i.test(message))fail('SESSIONS_CLIENT_UNSUPPORTED');
                if(/TOML|parse.*config/i.test(message))fail('CONFIG_TOML_INVALID');
                fail('SESSIONS_RPC_FAILED');
            }
            return value.result;
        }
    }catch(error){
        if(configuration){
            var mapped={SESSIONS_RPC_FAILED:'CONFIG_RPC_FAILED',SESSIONS_TIMEOUT:'CONFIG_RPC_TIMEOUT',SESSIONS_BUSY:'CONFIG_BUSY',SESSIONS_CLIENT_UNSUPPORTED:'CONFIG_CLIENT_UNSUPPORTED'};
            var current=String(error&&error.message||'');if(mapped[current])fail(mapped[current]);
        }
        throw error;
    }
};
Rpc.prototype.close=function(){this.process.close();};
function code(error,fallback){var value=String(error&&error.message||'');return /^[A-Z][A-Z0-9_]{3,70}$/.test(value)?value:(fallback||'SETUP_FAILED');}
function explain(value){var messages=JSON.parse(read(join(ROOT,'errors.json')));return messages[value]||['操作失败 ['+value+']。','保留失败阶段和诊断编号，请联系支持。'];}
function transferProgress(diagnostic,p,headers){
    if(!diagnostic)return;
    diagnostic.received_bytes=Number(p.received)||0;
    try{var header=exists(headers)?read(headers,16384):'',matches=header.match(/HTTP\/\S+\s+(\d+)/g);
        if(matches&&matches.length){diagnostic.transport_headers_received=true;if(!diagnostic.received_bytes)diagnostic.stage='transport_headers';
            // CONNECT headers alone do not prove that the origin replied.
            if(diagnostic.received_bytes)diagnostic.http_status=Number(matches[matches.length-1].match(/(\d+)$/)[1]);}
    }catch(ignored){}
    if(diagnostic.received_bytes)diagnostic.stage='streaming';
}
function transportDiagnostics(diagnostic,p,headers,started){
    if(!diagnostic)return;
    transferProgress(diagnostic,p,headers);diagnostic.elapsed_ms=Math.max(0,Date.now()-started);
    if(p.task&&!p.task.running)diagnostic.curl_exit_code=Number(p.task.terminationStatus);
    try{
        var raw=p.errorPath&&exists(p.errorPath)?read(p.errorPath,32768):'';
        var match=raw.match(/REALYU_TRANSFER http=(\d{3}) dns=([0-9.]+) tcp=([0-9.]+) tls=([0-9.]+) first=([0-9.]+) total=([0-9.]+) uploaded=([0-9.]+)/);
        if(match){
            diagnostic.timings_ms={};['dns','tcp','tls','first_byte','total'].forEach(function(name,i){var n=Number(match[i+2]);if(isFinite(n)&&n>=0)diagnostic.timings_ms[name]=Math.round(n*1000);});
            var uploaded=Number(match[7]);if(isFinite(uploaded)&&uploaded>=0)diagnostic.uploaded_bytes=uploaded;
            if(Number(match[1])>=100)diagnostic.http_status=Number(match[1]);
        }
        var header=exists(headers)?read(headers,16384):'',request=header.match(/^x-oneapi-request-id:\s*([A-Za-z0-9_-]{1,128})\s*$/im),ray=header.match(/^cf-ray:\s*([A-Fa-f0-9]{16,32}(?:-[A-Z]{3})?)\s*$/im);
        if(request)diagnostic.request_id=request[1];if(ray)diagnostic.cf_ray=ray[1];
        if(diagnostic.curl_exit_code===28){var t=diagnostic.timings_ms;
            diagnostic.timeout_phase=t?(t.tls===0?'connection':t.first_byte===0?'response_headers':'response_body'):'unknown';}
    }catch(ignored){}
}
function http(url,key,body,max,streaming,diagnostic){
    var directory=join(WORK,'http-'+uuid());mkdir(directory);var headers=join(directory,'headers');
    var trace=diagnostic||{},started=Date.now();trace.connect_timeout_seconds=60;trace.request_timeout_seconds=streaming?300:75;trace.proxy_environment_present=Object.keys(proxyEnvironment()).some(function(name){return !/^no_proxy$/i.test(name)&&Boolean(env[name]);});
    var args=['--disable','--silent','--show-error','--no-buffer','--proto','=https','--connect-timeout','60','--max-time',streaming?'300':'75','--max-filesize',String(max||1048576),'--dump-header',headers,'--header','Accept-Encoding: identity','--user-agent','Realyu-Setup/'+VERSION,'--write-out','%{stderr}\nREALYU_TRANSFER http=%{http_code} dns=%{time_namelookup} tcp=%{time_connect} tls=%{time_appconnect} first=%{time_starttransfer} total=%{time_total} uploaded=%{size_upload}\n','--config','-'];
    if(typeof trace.id==='string'&&/^[a-f0-9]{32}$/.test(trace.id))args.push('--header','X-Realyu-Probe-Id: '+trace.id);
    if(body!==undefined){var payload=join(directory,'request.json');write(payload,JSON.stringify(body));args=args.concat(['--header','Content-Type: application/json','--data-binary','@'+payload]);}
    args.push(url);var p=new Process('/usr/bin/curl',args,HOME),deadline=Date.now()+(streaming?305000:80000);
    try{p.send(key?'header = "Authorization: Bearer '+key+'"\n':'');p.endInput();var encoded=null,completed=false,data=[],status=0;
        if(streaming){
            while(Date.now()<deadline){
                var line;
                try{line=p.line(deadline);}catch(error){transferProgress(diagnostic,p,headers);if(code(error)==='SESSIONS_RPC_FAILED')break;if(code(error)==='SESSIONS_TIMEOUT')fail('IMAGE_TIMEOUT');throw error;}
                transferProgress(diagnostic,p,headers);
                if(p.received>(max||50331648))fail('IMAGE_RESPONSE_TOO_LARGE');
                if(line!==''){if(line.indexOf('data:')===0)data.push(line.slice(5).replace(/^ /,''));continue;}
                if(!data.length)continue;var raw=data.join('\n');data=[];if(raw==='[DONE]')break;
                var event=JSON.parse(raw);if(['error','response.failed','response.incomplete','response.cancelled'].indexOf(event.type)>=0)fail('IMAGE_GENERATION_FAILED');
                if(event.type==='response.output_item.done'&&event.item&&event.item.type==='image_generation_call')encoded=event.item.result;
                if(event.type==='response.completed'){if(!event.response||event.response.status!=='completed')fail('IMAGE_GENERATION_FAILED');(event.response.output||[]).forEach(function(item){if(item.type==='image_generation_call'&&item.result)encoded=item.result;});completed=true;break;}
            }
        }else{while(p.task.running){if(Date.now()>deadline)fail('KEY_NETWORK_ERROR');if(exists(p.out)&&Number(readBytes(p.out,max||1048576).length)>(max||1048576))fail('KEY_RESPONSE_INVALID');sleep(30);}}
        var header=exists(headers)?read(headers,16384):'',matches=header.match(/HTTP\/\S+\s+(\d+)/g);if(matches&&matches.length)status=Number(matches[matches.length-1].match(/(\d+)$/)[1]);
        var exitCode=p.task.running?0:Number(p.task.terminationStatus);
        transportDiagnostics(trace,p,headers,started);
        if(streaming&&!completed&&exitCode){if(exitCode===28)fail(trace.timeout_phase==='connection'?'IMAGE_CONNECTION_TIMEOUT':'IMAGE_TIMEOUT');if([35,51,58,60,77].indexOf(exitCode)>=0)fail('IMAGE_TLS_ERROR');if([6,7].indexOf(exitCode)>=0)fail('IMAGE_NETWORK_ERROR');if(exitCode===63)fail('IMAGE_RESPONSE_TOO_LARGE');if([18,52,55,56].indexOf(exitCode)>=0)fail('IMAGE_RESPONSE_INCOMPLETE');}
        if(status!==200){if(streaming)fail('IMAGE_HTTP_'+status);fail(({401:'KEY_REJECTED',403:'KEY_ACCESS_DENIED',429:'KEY_RATE_LIMITED'})[status]||(status?'KEY_HTTP_ERROR':'KEY_NETWORK_ERROR'));}
        if(streaming){if(!completed||typeof encoded!=='string'||!encoded)fail('IMAGE_RESPONSE_INCOMPLETE');return encoded;}
        if(Number(p.task.terminationStatus)!==0)fail('KEY_NETWORK_ERROR');return JSON.parse(read(p.out,max||1048576));
    }finally{transportDiagnostics(trace,p,headers,started);p.close();remove(directory);}
}
function keyValid(key){if(!/^sk-[A-Za-z0-9_-]{16,256}$/.test(key||''))fail('KEY_FORMAT_INVALID');return key;}
function validate(key,diagnostic){var value=http(KEY_URL,key,undefined,undefined,false,diagnostic),usage=value.data;if(value.code!==true||!usage||usage.object!=='token_usage'||!Number.isInteger(usage.expires_at)||!Number.isInteger(usage.total_available)||typeof usage.unlimited_quota!=='boolean')fail('KEY_RESPONSE_INVALID');if(usage.expires_at>0&&usage.expires_at<Date.now()/1000)fail('KEY_EXPIRED');}
function codexApplications(){
    if(env.REALYU_CODEX_APP){if(env.REALYU_CODEX_APP[0]!=='/'||!exists(join(env.REALYU_CODEX_APP,'Contents/Info.plist')))fail('CODEX_OVERRIDE_INVALID');return [env.REALYU_CODEX_APP];}
    var apps=[];
    ['/Applications',join(env.HOME,'Applications')].forEach(function(folder){['Codex.app','ChatGPT.app'].forEach(function(name){apps.push(join(folder,name));});});
    try{
        ObjC.import('AppKit');
        var urls=$.NSWorkspace.sharedWorkspace.URLsForApplicationsWithBundleIdentifier($('com.openai.codex'));
        for(var i=0;i<Number(urls.count);i++){var url=urls.objectAtIndex(i),path=ObjC.unwrap(url.path);if(Boolean(url.isFileURL)&&typeof path==='string'&&path[0]==='/'&&apps.indexOf(path)<0)apps.push(path);}
    }catch(error){if(REPORT)REPORT.codex_application_registry='unavailable';}
    return apps;
}
function findCodex(){
    var candidates=[],seen={},attempts=[],timedOut=false,unsupported=false;
    if(env.REALYU_CODEX_EXE){if(env.REALYU_CODEX_EXE[0]!=='/'||!exists(env.REALYU_CODEX_EXE))fail('CODEX_OVERRIDE_INVALID');candidates.push({path:env.REALYU_CODEX_EXE,source:'explicit'});}
    else{
        codexApplications().forEach(function(app){
                ['Contents/Resources/codex','Contents/Resources/codex-cli/bin/codex','Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'].forEach(function(relative){
                    candidates.push({path:join(app,relative),source:'desktop'});
                });
        });
        if(!env.REALYU_CODEX_APP){
            [join(env.HOME,'.local/bin/codex'),'/opt/homebrew/bin/codex','/usr/local/bin/codex'].forEach(function(path){candidates.push({path:path,source:'cli'});});
            String(env.PATH||'').split(':').forEach(function(folder){if(folder[0]==='/')candidates.push({path:join(folder,'codex'),source:'path'});});
        }
    }
    if(REPORT)REPORT.codex_candidates=attempts;
    for(var i=0;i<candidates.length;i++){
        var candidate=candidates[i],path=candidate.path;
        if(path[0]!=='/'||seen[path])continue;seen[path]=true;
        if(!exists(path))continue;
        var attributes=fm.attributesOfItemAtPathError($(path),null);
        if(!nil(attributes)&&ObjC.unwrap(attributes.objectForKey($.NSFileType))==='NSFileTypeDirectory')continue;
        // Fixed labels only: no private paths, CLI output or credentials in diagnostics.
        var attempt={source:candidate.source,status:'checking'};attempts.push(attempt);
        if(!fm.isExecutableFileAtPath($(path))){attempt.status='not_executable';continue;}
        try{
            var result=runProcess(path,['--version'],WORK,'',15000),match=result.text.match(/codex-cli\s+([0-9][0-9a-z.+-]*)/i);
            if(result.code!==0||!match){attempt.status='version_failed';continue;}
            attempt.version=match[1];
            var help=runProcess(path,['login','--help'],WORK,'',15000);
            if(help.code!==0){attempt.status='help_failed';continue;}
            if(help.text.indexOf('--with-api-key')<0){attempt.status='login_unsupported';unsupported=true;continue;}
            attempt.status='selected';CLI_VERSION=match[1];
            if(REPORT)REPORT.codex_cli_version=CLI_VERSION;
            return path;
        }catch(error){attempt.status=code(error)==='PROCESS_TIMEOUT'?'probe_timeout':'launch_failed';if(attempt.status==='probe_timeout')timedOut=true;}
    }
    if(timedOut)fail('CODEX_PROBE_TIMEOUT');
    if(unsupported)fail('CODEX_LOGIN_UNSUPPORTED');
    if(attempts.length)fail('CODEX_UNRUNNABLE');
    fail('CODEX_NOT_FOUND');
}
function rawConfig(result){var layers=result.layers||[];for(var i=0;i<layers.length;i++)if(layers[i].name.type==='user')return layers[i].config;return {};}
function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(function(k){return JSON.stringify(k)+':'+canonical(value[k]);}).join(',')+'}';return JSON.stringify(value);}
function unowned(value,changedLoginPreference){var copy=JSON.parse(JSON.stringify(value));['model_provider','model','openai_base_url','model_reasoning_effort','service_tier','cli_auth_credentials_store','profile','model_catalog_json'].forEach(function(k){delete copy[k];});if(changedLoginPreference)delete copy.forced_login_method;[['model_providers','realyu'],['mcp_servers','realyu_images'],['mcp_servers','image_generation']].forEach(function(pair){if(copy[pair[0]]){delete copy[pair[0]][pair[1]];if(!Object.keys(copy[pair[0]]).length)delete copy[pair[0]];}});return canonical(copy);}
function configSource(name){var type=name&&name.type;return ['user','system','mdm','project','sessionFlags','packagedDefaults','enterpriseManaged','legacyManagedConfigTomlFromFile','legacyManagedConfigTomlFromMdm'].indexOf(type)>=0?type:'unknown';}
function configOrigin(result,field){var origin=(result.origins||{})[field];return configSource(origin&&origin.name);}
function configFailure(error,field,result){var origin=configOrigin(result||{},field);if(REPORT){REPORT.config_field=field;REPORT.config_origin=origin;REPORT.codex_cli_version=CLI_VERSION;}print('[配置核验] 字段='+field+'；来源='+origin+'；Codex='+CLI_VERSION);fail(error);}
function checkConnection(result){var c=result.config||{};[['model_provider','realyu','CONFIG_PROVIDER_OVERRIDDEN'],['openai_base_url',BASE,'CONFIG_BASE_URL_OVERRIDDEN'],['cli_auth_credentials_store','file','CONFIG_CREDENTIAL_STORE_OVERRIDDEN']].forEach(function(item){if(!Object.prototype.hasOwnProperty.call(c,item[0]))configFailure('CONFIG_CLIENT_UNSUPPORTED',item[0],result);if(c[item[0]]!==item[1])configFailure(item[2],item[0],result);});}
function transaction(files,backup){
    var originals={},changed=[];Object.keys(files).forEach(function(name){var path=join(HOME,name);safe(path);originals[name]=exists(path)?readBytes(path):null;if(originals[name])atomicBytes(join(backup,name),originals[name]);});
    try{Object.keys(files).forEach(function(name){atomicBytes(join(HOME,name),files[name]);changed.push(name);});}
    catch(error){var failed=false;changed.forEach(function(name){try{if(originals[name])atomicBytes(join(HOME,name),originals[name]);else remove(join(HOME,name));}catch(e){failed=true;}});if(failed)fail('CONFIG_RESTORE_FAILED');throw error;}
}
function imageEntry(){var imageEnv=proxyEnvironment();imageEnv[KIND==='workbuddy'?'REALYU_WORKBUDDY_HOME':'REALYU_CODEX_HOME']=HOME;return {command:'/usr/bin/osascript',args:['-l','JavaScript',join(ROOT,'mac.js'),'images',KIND,HOME,ROOT],env:imageEnv};}
function ownedImage(entry){if(!entry)return true;var args=entry.args||[],environment=entry.env||{};return !entry.url&&((environment.REALYU_CODEX_HOME===HOME||environment.REALYU_WORKBUDDY_HOME===HOME)&&((args.indexOf(join(ROOT,'mac.js'))>=0)||args.some(function(a){return typeof a==='string'&&a.indexOf(HOME+'/realyu-runtime/')===0&&(a.endsWith('/mac.js')||a.endsWith('/realyu_images.py'));})||args.indexOf(join(HOME,'realyu_images.py'))>=0));}
function installCodex(key,backup){
    CLI=findCodex();print('[配置] Codex CLI '+CLI_VERSION+'；正在读取配置来源…');var shadow=join(WORK,'connection');mkdir(shadow);var source=exists(join(HOME,'config.toml'))?read(join(HOME,'config.toml')):'';var oldAuth=exists(join(HOME,'auth.json'))?readBytes(join(HOME,'auth.json')):null;write(join(shadow,'config.toml'),source);
    var rpc=null,before,changedLoginPreference=false;
    try{if(REPORT)REPORT.config_step='read_original';rpc=new Rpc(CLI,shadow);var beforeRead=rpc.call('config/read',{includeLayers:true});before=rawConfig(beforeRead);if(!ownedImage((before.mcp_servers||{}).image_generation))fail('CONFIG_IMAGE_TOOL_CONFLICT');
        if((beforeRead.config||{}).forced_login_method==='chatgpt'){
            var origin=configOrigin(beforeRead,'forced_login_method');
            if(origin==='unknown')configFailure('CONFIG_LOGIN_SOURCE_UNKNOWN','forced_login_method',beforeRead);
            if(origin!=='user'||before.forced_login_method!=='chatgpt')configFailure('CONFIG_LOGIN_POLICY','forced_login_method',beforeRead);
            print('[配置] 检测到用户设置的 ChatGPT 登录偏好，正在临时副本中切换为 API Key…');if(REPORT)REPORT.config_step='reset_user_login_preference';
            rpc.call('config/batchWrite',{filePath:join(shadow,'config.toml'),edits:[{keyPath:'forced_login_method',value:null,mergeStrategy:'replace'}]});changedLoginPreference=true;
            rpc.close();rpc=null;rpc=new Rpc(CLI,shadow);beforeRead=rpc.call('config/read',{includeLayers:true});
            if((beforeRead.config||{}).forced_login_method==='chatgpt')configFailure('CONFIG_LOGIN_POLICY','forced_login_method',beforeRead);
        }
        var entry=imageEntry();entry.tool_timeout_sec=360;entry.startup_timeout_sec=60;entry.enabled_tools=['generate_image','edit_image','diagnose_image'];entry.tools={generate_image:{approval_mode:'prompt'},edit_image:{approval_mode:'prompt'},diagnose_image:{approval_mode:'prompt'}};
        var values={model_provider:'realyu',model:'gpt-6-astra',openai_base_url:BASE,model_reasoning_effort:'high',service_tier:'default',cli_auth_credentials_store:'file',profile:null,model_catalog_json:join(ROOT,'models.json'),'model_providers.realyu':{name:'RealYu API',base_url:BASE,wire_api:'responses',requires_openai_auth:true},'mcp_servers.realyu_images':null,'mcp_servers.image_generation':entry};
        if(REPORT)REPORT.config_step='write_connection';var writeResult=rpc.call('config/batchWrite',{filePath:join(shadow,'config.toml'),edits:Object.keys(values).map(function(k){return {keyPath:k,value:values[k],mergeStrategy:'replace'};})});
        if(writeResult&&writeResult.status==='okOverridden')print('[配置] 检测到配置覆盖，来源='+configSource(writeResult.overriddenMetadata&&writeResult.overriddenMetadata.overridingLayer&&writeResult.overriddenMetadata.overridingLayer.name)+'；正在核验实际生效值…');
        if(REPORT)REPORT.config_step='verify_fresh_connection';rpc.close();rpc=null;rpc=new Rpc(CLI,shadow);
        var after=rpc.call('config/read',{includeLayers:true});if(unowned(before,changedLoginPreference)!==unowned(rawConfig(after),changedLoginPreference))fail('CONFIG_MERGE_UNSUPPORTED');checkConnection(after);
        if((after.config||{}).forced_login_method==='chatgpt')configFailure('CONFIG_LOGIN_POLICY','forced_login_method',after);
        var requirements=null;try{requirements=rpc.call('configRequirements/read',{});}catch(e){if(code(e)!=='CONFIG_CLIENT_UNSUPPORTED')throw e;}
        var allowed=requirements&&requirements.requirements&&requirements.requirements.allowedLoginMethods;if(Array.isArray(allowed)&&allowed.indexOf('api')<0)configFailure('CONFIG_LOGIN_POLICY','allowed_login_methods',after);
    }finally{if(rpc)rpc.close();}
    var result=runProcess(CLI,['login','--with-api-key'],shadow,key+'\n',20000);if(result.code!==0)fail('CODEX_LOGIN_FAILED');var auth=JSON.parse(read(join(shadow,'auth.json')));if(auth.OPENAI_API_KEY!==key||auth.tokens)fail('CODEX_CREDENTIALS_INVALID');
    if((exists(join(HOME,'config.toml'))?read(join(HOME,'config.toml')):'')!==source)fail('CONFIG_CHANGED');
    if(Boolean(oldAuth)!==exists(join(HOME,'auth.json'))||(oldAuth&&!oldAuth.isEqualToData(readBytes(join(HOME,'auth.json')))))fail('CONFIG_CHANGED');
    transaction({'config.toml':readBytes(join(shadow,'config.toml')),'auth.json':readBytes(join(shadow,'auth.json'))},backup);
}
function strictJson(text){
    // Reject duplicate keys before JSON.parse can silently overwrite them.
    var tokens=text.match(/"(?:\\.|[^"\\])*"|[{}\[\],:]|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null/g)||[],position=0;
    function value(){var token=tokens[position++];if(token==='{'){var seen={};if(tokens[position]==='}'){position++;return;}for(;;){var key=JSON.parse(tokens[position++]);if(Object.prototype.hasOwnProperty.call(seen,key))fail('CONFIG_JSON_INVALID');Object.defineProperty(seen,key,{value:true});if(tokens[position++]!==':')fail('CONFIG_JSON_INVALID');value();var next=tokens[position++];if(next==='}')break;if(next!==',')fail('CONFIG_JSON_INVALID');}}
        else if(token==='['){if(tokens[position]===']'){position++;return;}for(;;){value();var end=tokens[position++];if(end===']')break;if(end!==',')fail('CONFIG_JSON_INVALID');}}}
    try{value();return JSON.parse(text);}catch(e){fail('CONFIG_JSON_INVALID');}
}
function findWorkBuddy(){
    var apps=env.REALYU_WORKBUDDY_APP?[env.REALYU_WORKBUDDY_APP]:['/Applications/WorkBuddy.app',join(env.HOME,'Applications/WorkBuddy.app')];
    for(var i=0;i<apps.length;i++){
        var app=apps[i];if(app[0]!=='/'||!exists(join(app,'Contents/Info.plist')))continue;
        var version='unknown',known=false;
        try{var result=runProcess('/usr/bin/plutil',['-extract','CFBundleShortVersionString','raw','-o','-',join(app,'Contents/Info.plist')],HOME,'');
            var value=result.text.trim();if(!result.code&&/^v?\d{1,4}\.\d{1,4}\.\d{1,4}(?:\.\d{1,6})?(?:[-+][0-9A-Za-z.+-]{1,40})?$/.test(value)){version=value;known=true;}
        }catch(error){}
        var numbers=version.replace(/^v/,'').split(/[.+-]/).map(Number),older=known&&(numbers[0]<5||(numbers[0]===5&&(numbers[1]<6||(numbers[1]===6&&numbers[2]<2))));
        if(REPORT){REPORT.workbuddy_version=version;REPORT.workbuddy_version_policy='advisory';REPORT.workbuddy_version_warning=!known?'unknown':older?'older_than_reference':null;}
        if(!known||older)print('[兼容提示] '+(known?'WorkBuddy '+version+' 早于参考版本 5.6.2':'未能读取标准 WorkBuddy 版本号')+'；继续检查配置格式并备份写入。若客户端无法加载模型或图片工具，请更新 WorkBuddy。');
        return app;
    }
    fail('WORKBUDDY_NOT_FOUND');
}
function installWorkBuddy(key,backup){
    findWorkBuddy();
    var modelPath=join(HOME,'models.json'),mcpPath=join(HOME,'mcp.json');var original=exists(modelPath)?read(modelPath,1048576):null,originalMcp=exists(mcpPath)?read(mcpPath,1048576):null;
    var document=original===null?[]:strictJson(original),models=Array.isArray(document)?document:document.models;if(!Array.isArray(models))fail('CONFIG_UNSUPPORTED');
    var response=http(BASE+'/models',key),ids=[];if(!Array.isArray(response.data))fail('MODELS_RESPONSE_INVALID');response.data.forEach(function(item){if(item&&/^gpt-[0-9][a-z0-9._-]{0,79}$/.test(item.id)&&ids.indexOf(item.id)<0)ids.push(item.id);});if(!ids.length||ids.length>64)fail('MODELS_NONE_AVAILABLE');
    var order=['gpt-6.1-sol','gpt-6-astra','gpt-6-sol','gpt-6-luna','gpt-5.6-sol','gpt-5.6-terra','gpt-5.6-luna','gpt-5.5'];ids.sort(function(a,b){var x=order.indexOf(a),y=order.indexOf(b);return (x<0?99:x)-(y<0?99:y)||a.localeCompare(b);});
    var seen={};models.forEach(function(model){if(!model||typeof model.id!=='string')fail('CONFIG_UNSUPPORTED');var id=model.id.replace(/^custom-local:/,'');if(seen[id])fail('CONFIG_DUPLICATE_MODEL');seen[id]=model;});
    ids.forEach(function(id){var model=seen[id];if(model&&model.url!==BASE+'/chat/completions')fail('CONFIG_MODEL_CONFLICT');if(!model){model={};models.push(model);}Object.assign(model,{id:id,name:id,vendor:'RealYu API',url:BASE+'/chat/completions',apiKey:key,maxInputTokens:200000,maxOutputTokens:4096,supportsToolCall:true,supportsImages:false,supportsReasoning:false,useCustomProtocol:false});});
    models.forEach(function(model){if(model.url===BASE+'/chat/completions')model.apiKey=key;});
    if(!Array.isArray(document)&&document.availableModels&&document.availableModels.length)ids.forEach(function(id){if(document.availableModels.indexOf(id)<0)document.availableModels.push(id);});
    var mcp=originalMcp===null?{mcpServers:{}}:strictJson(originalMcp);if(!mcp.mcpServers||typeof mcp.mcpServers!=='object'||Array.isArray(mcp.mcpServers))fail('CONFIG_JSON_INVALID');if(!ownedImage(mcp.mcpServers.image_generation))fail('CONFIG_IMAGE_TOOL_CONFLICT');mcp.mcpServers.image_generation=imageEntry();
    if((exists(modelPath)?read(modelPath):null)!==original||(exists(mcpPath)?read(mcpPath):null)!==originalMcp)fail('CONFIG_CHANGED');
    transaction({'models.json':utf8(JSON.stringify(document,null,2)+'\n'),'mcp.json':utf8(JSON.stringify(mcp,null,2)+'\n')},backup);
}
function resumeOffline(rpc,item,overrides){var params={includeLayers:false};if(item.cwd)params.cwd=item.cwd;var config=rpc.call('config/read',params).config,disabled={},providers={};Object.keys(config.mcp_servers||{}).forEach(function(name){disabled[name]={enabled:false,required:false};});Object.keys(config.model_providers||{}).forEach(function(name){providers[name]={base_url:'http://127.0.0.1:1/v1',supports_websockets:false};});return rpc.call('thread/resume',Object.assign({threadId:item.id,excludeTurns:true,config:{mcp_servers:disabled,'features.shell_snapshot':false,model_providers:providers,openai_base_url:'http://127.0.0.1:1/v1'}},overrides||{}));}
function readThreadIndex(db){
    var query=runProcess('/usr/bin/sqlite3',['-init','/dev/null','-readonly','-batch','-noheader','-list','-separator','|',db,'SELECT hex(id), CASE WHEN archived THEN 1 ELSE 0 END FROM threads'],HOME,'');if(query.code)fail('SESSIONS_INDEX_UNSUPPORTED');var rows=[];
    String(query.text||'').split(/\r?\n/).forEach(function(line){if(!line)return;var match=line.match(/^((?:[0-9a-fA-F]{2})+)\|([01])$/);if(!match)fail('SESSIONS_INDEX_UNSUPPORTED');var id;try{id=decodeURIComponent(match[1].replace(/(..)/g,'%$1'));}catch(e){fail('SESSIONS_INDEX_UNSUPPORTED');}rows.push({id:id,archived:match[2]==='1'});});return rows;
}
function migrate(backup){
    var probe=join(WORK,'session-probe');mkdir(probe);
    write(join(probe,'config.toml'),'model_provider="realyu"\nmodel="gpt-6-luna"\n[model_providers.realyu]\nname="Offline probe"\nbase_url="http://127.0.0.1:1/v1"\nwire_api="responses"\nrequires_openai_auth=true\n');
    write(join(probe,'auth.json'),'{"OPENAI_API_KEY":"sk-offline-capability-probe"}');
    var support=new Rpc(CLI,probe);try{var test=support.call('thread/start',{cwd:probe,modelProvider:'realyu'});support.call('thread/settings/update',{threadId:test.thread.id,model:test.model});}finally{support.close();}
    var rpc=new Rpc(CLI,HOME),items={},archived=0,databases=list(HOME).filter(function(p){return /^state_\d+\.sqlite$/.test(p);}).sort(function(a,b){return Number(a.match(/\d+/)[0])-Number(b.match(/\d+/)[0]);}),journal=join(HOME,'realyu-session-migration.json'),retry={};
    try{
        if(exists(journal)){var old=JSON.parse(read(journal));if(old.schema!==2||old.phase!=='retry'||!old.archived||Object.keys(old.archived).length)fail('SESSIONS_JOURNAL_INVALID');retry=old.failures||{};}
        var cursor=null,cursors={};do{var page=rpc.call('thread/list',{archived:false,limit:100,cursor:cursor,sortKey:'created_at',sortDirection:'asc',modelProviders:[],sourceKinds:['cli','vscode','exec','appServer','subAgent','subAgentReview','subAgentCompact','subAgentThreadSpawn','subAgentOther','unknown']});page.data.forEach(function(item){if(items[item.id])fail('SESSIONS_CHANGED');items[item.id]=item;});cursor=page.nextCursor;if(cursor){if(cursors[cursor])fail('SESSIONS_CHANGED');cursors[cursor]=true;}}while(cursor);
        if(databases.length){var db=join(HOME,databases[databases.length-1]);safe(db);readThreadIndex(db).forEach(function(row){if(row.archived){archived++;delete items[row.id];return;}if(!items[row.id]){try{var item=rpc.call('thread/read',{threadId:row.id,includeTurns:false}).thread;if(!item||item.id!==row.id)fail('SESSIONS_VERIFY_FAILED');items[row.id]=item;}catch(error){items[row.id]={id:row.id,read_error:code(error)};}}});}
    }finally{rpc.close();}
    var roots=Object.keys(items).map(function(id){return items[id];}).filter(function(item){return !item.archived&&!item.parentThreadId&&!(item.source&&typeof item.source==='object'&&item.source.subAgent);});
    var failures={},original={},changing={},status={status:'migrating',total:roots.length,migrated:0,already_current:0,failed:0,skipped_archived:archived,skipped_children:Object.keys(items).length-roots.length};REPORT.sessions=status;
    roots.forEach(function(item){if(item.read_error)failures[item.id]=item.read_error;if(item.modelProvider!=='realyu'||retry[item.id])changing[item.id]=true;});
    if(Object.keys(changing).length){var destination=join(backup,'sessions');mkdir(destination);list(HOME).filter(function(name){return /^(state|thread_history)_\d+\.sqlite$/.test(name);}).forEach(function(name){safe(join(HOME,name));var result=runProcess('/usr/bin/sqlite3',['-init','/dev/null','-readonly',join(HOME,name),'.backup '+JSON.stringify(join(destination,name))],HOME,'');if(result.code)fail('SESSIONS_BACKUP_FAILED');});}
    write(journal,JSON.stringify({schema:2,phase:'retry',archived:{}}));
    for(var offset=0;offset<roots.length;offset+=10){var batch=roots.slice(offset,offset+10);batch.forEach(function(item){if(!changing[item.id]||failures[item.id])return;try{var path=safe(item.path||'');if(path.indexOf(HOME+'/')!==0)fail('SESSIONS_PATH_UNSAFE');var target=join(backup,'rollout-'+item.id+'.jsonl'),before=readBytes(path);atomicBytes(target,before);if(!before.isEqualToData(readBytes(path)))fail('SESSIONS_CHANGED');}catch(error){failures[item.id]=code(error,'SESSIONS_BACKUP_FAILED');}});
        ['read','save','verify'].forEach(function(phase){var rpc=null;try{batch.forEach(function(item){if(failures[item.id]||(phase!=='verify'&&!changing[item.id]))return;try{if(!rpc)rpc=new Rpc(CLI,HOME);var result=resumeOffline(rpc,item,phase==='save'?{modelProvider:'realyu',model:original[item.id].model}:{});if(!result.thread||result.thread.id!==item.id||!result.model)fail('SESSIONS_VERIFY_FAILED');if(phase==='read')original[item.id]={model:result.model,reasoningEffort:result.reasoningEffort};else{if(result.modelProvider!=='realyu')fail('SESSIONS_VERIFY_FAILED');if(phase==='save'){var settings={threadId:item.id,model:original[item.id].model};if(original[item.id].reasoningEffort!==null&&original[item.id].reasoningEffort!==undefined)settings.effort=original[item.id].reasoningEffort;rpc.call('thread/settings/update',settings);}else if(original[item.id]&&(result.model!==original[item.id].model||result.reasoningEffort!==original[item.id].reasoningEffort))fail('SESSIONS_SETTINGS_MISMATCH');}rpc.call('thread/unsubscribe',{threadId:item.id});}catch(error){failures[item.id]=code(error,'SESSIONS_RPC_FAILED');if(rpc){rpc.close();rpc=null;}}});}finally{if(rpc)rpc.close();}});
        batch.forEach(function(item){if(failures[item.id])status.failed++;else if(changing[item.id])status.migrated++;else status.already_current++;});write(journal,JSON.stringify({schema:2,phase:'retry',archived:{},failures:failures}));
        var processed=Math.min(offset+10,roots.length);if(processed<roots.length&&processed%50===0)print('旧会话：已处理 '+processed+'/'+roots.length);
    }
    status.status=Object.keys(failures).length?'partial':'complete';if(status.status==='complete')remove(journal);else REPORT.code='SESSIONS_VERIFY_FAILED';
    print('旧会话处理结束：更新 '+status.migrated+'，已就绪 '+status.already_current+'，未完成 '+status.failed+'。');
}
function imageKey(){
    if(env.REALYU_API_KEY)return keyValid(env.REALYU_API_KEY);
    if(KIND==='workbuddy'){var doc=strictJson(read(join(HOME,'models.json'),1048576)),models=Array.isArray(doc)?doc:doc.models,keys=[];models.forEach(function(model){if(model.url===BASE+'/chat/completions'&&keys.indexOf(model.apiKey)<0)keys.push(model.apiKey);});if(keys.length!==1)fail('IMAGE_CONFIG_INVALID');return keyValid(keys[0]);}
    CLI=findCodex();var rpc=new Rpc(CLI,HOME);try{var config=rpc.call('config/read',{includeLayers:false}).config,provider=(config.model_providers||{})[config.model_provider];if(!provider||provider.base_url.replace(/\/$/,'')!==BASE||provider.requires_openai_auth!==true)fail('IMAGE_CONFIG_INVALID');}finally{rpc.close();}
    return keyValid(JSON.parse(read(join(HOME,'auth.json'),1048576)).OPENAI_API_KEY);
}
function imageOutput(){var path=env.REALYU_IMAGE_OUTPUT_DIR||join(HOME,'generated_images/realyu');mkdir(path);var test=join(path,'.write-'+uuid());write(test,'');remove(test);return path;}
function mime(data){var b64=ObjC.unwrap(data.base64EncodedStringWithOptions(0));if(b64.indexOf('iVBORw0KGgo')===0)return 'image/png';if(b64.indexOf('/9j/')===0)return 'image/jpeg';if(Number(data.length)>=12&&ObjC.unwrap(data.subdataWithRange($.NSMakeRange(0,4)).base64EncodedStringWithOptions(0))==='UklGRg=='&&ObjC.unwrap(data.subdataWithRange($.NSMakeRange(8,4)).base64EncodedStringWithOptions(0))==='V0VCUA==')return 'image/webp';fail('IMAGE_FORMAT_INVALID');}
function imageCall(name,args){
    var diagnostic={id:uuid(),version:VERSION,stage:'input',request_attempted:false,image_received:false};
    try{var tools=JSON.parse(read(join(ROOT,'tools.json'))),quality=args.quality||'auto',size=args.size||'auto';if(typeof args.prompt!=='string'||!args.prompt.trim()||args.prompt.length>16000||['auto','low','medium','high'].indexOf(quality)<0||tools[0].inputSchema.properties.size.enum.indexOf(size)<0)fail('IMAGE_INPUT_INVALID');var content=[{type:'input_text',text:args.prompt}];
        if(name==='edit_image'){if(typeof args.image_path!=='string'||args.image_path[0]!=='/')fail('IMAGE_PATH_INVALID');var data=readBytes(args.image_path,20971520);content.push({type:'input_image',image_url:'data:'+mime(data)+';base64,'+ObjC.unwrap(data.base64EncodedStringWithOptions(0))});}
        diagnostic.stage='credentials';var key=imageKey();diagnostic.stage='output_directory';var folder=imageOutput();diagnostic.stage='connection';diagnostic.request_attempted=true;
        var encoded=http(BASE+'/responses',key,{model:'gpt-5.6-luna',instructions:'Generate or edit the requested image.',input:[{role:'user',content:content}],tools:[{type:'image_generation',model:'gpt-image-2',quality:quality,size:size,output_format:'png'}],tool_choice:{type:'image_generation'},stream:true,store:false},50331648,true,diagnostic);
        diagnostic.stage='response';var image=$.NSData.alloc.initWithBase64EncodedStringOptions($(encoded),0);if(nil(image)||mime(image)!=='image/png')fail('IMAGE_FORMAT_INVALID');diagnostic.image_received=true;diagnostic.stage='save';var name=uuid(),original=join(folder,name+'.png'),preview=join(folder,name+'-preview.png');atomicBytes(original,image);
        var dimensions=runProcess('/usr/bin/sips',['-g','pixelWidth','-g','pixelHeight',original],HOME,'').text;var width=Number((dimensions.match(/pixelWidth:\s+(\d+)/)||[])[1]),height=Number((dimensions.match(/pixelHeight:\s+(\d+)/)||[])[1]);if(!width||!height||width*height>40000000)fail('IMAGE_DIMENSIONS_INVALID');
        var thumb=runProcess('/usr/bin/sips',['-Z','512',original,'--out',preview],HOME,'');if(thumb.code)fail('IMAGE_PREVIEW_FAILED');if($.chmod(preview,384)!==0)fail('FILESYSTEM_ACCESS_DENIED');var previewBytes=readBytes(preview,2097152);
        return {content:[{type:'text',text:JSON.stringify({file:original,original_file:original,preview_file:preview,original_uri:fileURI(original),preview_uri:fileURI(preview),bytes:Number(image.length),preview_bytes:Number(previewBytes.length),model:'gpt-image-2',note:'The attached image is a small preview. Use the original file for sharing and further edits.'})},{type:'image',mimeType:'image/png',data:ObjC.unwrap(previewBytes.base64EncodedStringWithOptions(0))}]};
    }catch(error){diagnostic.code=code(error,'IMAGE_CLIENT_ERROR');try{var diagnostics=join(HOME,'realyu-diagnostics');mkdir(diagnostics);write(join(diagnostics,'image-'+diagnostic.id+'.json'),JSON.stringify(diagnostic));}catch(ignored){}var message=explain(diagnostic.code);return {isError:true,content:[{type:'text',text:message[0]+' 下一步：'+message[1]+' No automatic retry was made. Diagnostic: '+JSON.stringify(diagnostic)}]};}
}
function diagnose(){var checks=[],key=null;['credentials','output_directory','gateway','key_check'].forEach(function(stage){var diagnostic={id:uuid(),stage:stage};try{if(stage==='credentials')key=imageKey();else if(stage==='output_directory')imageOutput();else if(stage==='gateway'){if(http(STATUS_URL,null,undefined,undefined,false,diagnostic).success!==true)fail('IMAGE_RESPONSE_INVALID');}else validate(keyValid(key),diagnostic);checks.push({stage:stage,status:'passed',diagnostic:diagnostic});}catch(error){checks.push({stage:stage,status:'failed',code:code(error,'IMAGE_CHECK_FAILED'),diagnostic:diagnostic});}});return {content:[{type:'text',text:JSON.stringify({version:VERSION,generation_requests:0,checks:checks,all_passed:checks.every(function(item){return item.status==='passed';})})}]};}
function images(){var initialized=false,line;while((line=readLine())!==null){var request=null;try{request=JSON.parse(line);if(!request||request.id===undefined)continue;var result,params=request.params||{};
        switch(request.method){case 'initialize':var version=params.protocolVersion;result={protocolVersion:['2024-11-05','2025-03-26','2025-06-18','2025-11-25'].indexOf(version)>=0?version:'2025-11-25',capabilities:{tools:{listChanged:false}},serverInfo:{name:'image-generation',version:VERSION}};initialized=true;break;
            case 'ping':result={};break;case 'tools/list':if(!initialized)fail('MCP_NOT_INITIALIZED');result={tools:JSON.parse(read(join(ROOT,'tools.json')))};break;
            case 'tools/call':if(!initialized)fail('MCP_NOT_INITIALIZED');if(params.name==='diagnose_image')result=diagnose();else if(['generate_image','edit_image'].indexOf(params.name)>=0)result=imageCall(params.name,params.arguments||{});else fail('MCP_METHOD_UNKNOWN');break;default:fail('MCP_METHOD_UNKNOWN');}
        print(JSON.stringify({jsonrpc:'2.0',id:request.id,result:result}));}catch(error){print(JSON.stringify({jsonrpc:'2.0',id:request?request.id:null,error:{code:code(error)==='MCP_METHOD_UNKNOWN'?-32601:-32600,message:'Invalid or unsupported request'}}));}}}
function run(argv){
    var mode=argv[0];KIND=argv[1];HOME=safe(argv[2]);ROOT=safe(argv[3]);mkdir(HOME);var runtime=join(HOME,'realyu-runtime');mkdir(runtime);WORK=join(runtime,'work-'+uuid());mkdir(WORK);
    try{
        if(mode==='images'){images();return;}
        REPORT={id:uuid(),client_version:VERSION,platform:'darwin',stage:'key_validation',status:'running'};var key=keyValid(readLine());print('[1/4] 验证密钥…');validate(key);
        REPORT.stage='configuration';print('[2/4] 备份并写入配置与图片组件…');var backup=join(HOME,'realyu-backups/'+REPORT.id);mkdir(backup);
        if(KIND==='workbuddy')installWorkBuddy(key,backup);else installCodex(key,backup);key=null;REPORT.status='success';
        if(KIND==='codex'){REPORT.stage='sessions';print('[3/4] 检查旧会话…');try{migrate(backup);}catch(error){REPORT.code=code(error,'SESSIONS_MIGRATION_FAILED');REPORT.status='success_with_warnings';}}
        if(REPORT.code){REPORT.status='success_with_warnings';var warning=explain(REPORT.code);print(warning[0]+' 下一步：'+warning[1]);}
        print('[4/4] 设置完成。请重启 '+(KIND==='workbuddy'?'WorkBuddy':'Codex')+'；图片组件已包含，无需额外下载 Python、Node 或运行时。');
    }catch(error){if(!REPORT)throw error;REPORT.status='failed';REPORT.code=code(error);var details=explain(REPORT.code);print('失败步骤：'+REPORT.stage+' ['+REPORT.code+']\n原因：'+details[0]+'\n下一步：'+details[1]);}
    finally{remove(WORK);if(REPORT){var directory=join(HOME,'realyu-diagnostics');mkdir(directory);write(join(directory,REPORT.id+'.json'),JSON.stringify(REPORT));if(REPORT.code)print('诊断编号：'+REPORT.id);}}
    if(REPORT&&REPORT.status==='failed')throw new Error(REPORT.code);
}
